# Fixture harness
