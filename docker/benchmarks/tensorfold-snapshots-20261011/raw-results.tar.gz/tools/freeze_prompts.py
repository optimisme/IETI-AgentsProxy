"""Executed with the deployed tokenizer, without GPU inference or downloads."""
import hashlib
import json
import random
from pathlib import Path
from tokenizers import Tokenizer
from tensorfold.cuda.chat_template import ChatTemplate
from tensorfold.cuda.markers import resume_points

model=Path('/root/.cache/huggingface/hub/models--TensorFold--Qwen3.8-Flash-Next-MLX-4bit-MTP/snapshots/2b170fa6309d5d1ee380b35636075fac7945f286')
tok=Tokenizer.from_file(str(model/'tokenizer.json'));template=ChatTemplate(model);points=resume_points(model)
def encode(messages):
    return tok.encode(template.render(messages,tools=None,enable_thinking=True,extra={'reasoning_effort':'low'}),add_special_tokens=False).ids
system='You are a careful programming assistant in a reproducible offline benchmark. The repository and all code below are synthetic. Explain practical checks as a long numbered list, without a conclusion.\n' + '\n'.join(f'Engineering rule {i}: preserve behavior, handle empty inputs, check exception paths, and explain the reasoning.' for i in range(40))
continuation='\n'.join(f'Check {i}: inspect validation, input boundaries, concurrency, resource ownership and exact return values.' for i in range(20))
assistant='I have inspected the supplied code and identified validation and resource ownership as the next areas to review.'
users=[]
for user,target in enumerate([1800]*8+[7400]*7+[65000]):
    rng=random.Random(f'snapshot-test-20261011-user{user}');rows=[]
    for i in range(max(200,target//4)):
        rows.append(f'def helper_{i}(value):\n    # fixture {rng.randrange(100000000)} for project {user}\n    return value + {rng.randrange(1000)}\n')
    text='\n'.join(rows);prefix=f'Project {user}; unique fixture {hashlib.sha256(str(user).encode()).hexdigest()}.\n';suffix='\nReview this code. Start a long numbered list of concrete checks and continue without concluding.'
    lo,hi=0,len(text)
    while lo<hi:
        mid=(lo+hi)//2
        messages=[{'role':'system','content':system},{'role':'user','content':prefix+text[:mid]+suffix}]
        if len(encode(messages))<target:lo=mid+1
        else:hi=mid
    base=[{'role':'system','content':system},{'role':'user','content':prefix+text[:lo]+suffix}]
    growth1=base+[{'role':'assistant','content':assistant},{'role':'user','content':'Next review A.\n'+continuation}]
    growth2=growth1+[{'role':'assistant','content':assistant},{'role':'user','content':'Next review B.\n'+continuation}]
    branch=growth1+[{'role':'assistant','content':assistant},{'role':'user','content':'Alternative review C: revisit the earlier design.\n'+continuation}]
    after=branch+[{'role':'assistant','content':assistant},{'role':'user','content':'Continue alternative review D.\n'+continuation}]
    phases={}
    for phase,messages in [('project-cold',base),('growth-1',growth1),('growth-2',growth2),('branch-previous',branch),('branch-continue',after)]:
        ids=encode(messages)
        assert len(ids)+128+8<75000,(phase,len(ids))
        phases[phase]={'messages':messages,'tokens':len(ids),'snapshot_points':points(ids),'entry_end':len(ids)-1,
                       'token_sha256':hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()}
    users.append({'user':user,'base_target_tokens':target,'phases':phases})
out={'description':'16 synthetic programming histories: 8 short, 7 medium, 1 approximately 65k; two appended turns, branch to previous turn, then continue branch. Fixed synthetic assistant history is identical across arms.',
     'tokenizer_sha256':hashlib.sha256((model/'tokenizer.json').read_bytes()).hexdigest(),'shared_system_tokens':len(tok.encode(system).ids),'users':users}
print(json.dumps(out))
