import difflib
import hashlib
import json
import re
import statistics
from pathlib import Path
import bench_long_context as bench

ROOT=Path('/tmp/tensorfold-snapshots-20261011');R=ROOT/'results'
corpus=json.loads((ROOT/'prompts.json').read_text())
rows=[];variants={};pairs=[]
phases=['decode-control','project-cold','growth-1','growth-2','branch-previous','branch-continue']
for keep in (32,48,64):
    variant={'keep':keep,'phases':{}}
    startup=(R/f'keep{keep}-startup.log').read_text()
    match=re.search(r'startup estimate ([0-9.]+) GiB within ([0-9.]+) GiB',startup)
    variant['startup_estimate_gib']=float(match[1]) if match else None
    variant['startup_budget_gib']=float(match[2]) if match else None
    patch_line=next(l for l in startup.splitlines() if l.startswith('[snapshot-test] {'))
    variant['source_verification']=json.loads(patch_line.removeprefix('[snapshot-test] '))
    for phase in phases:
        stem=f'keep{keep}-{phase}';s=json.loads((R/(stem+'-summary.json')).read_text())
        records=[json.loads((R/f'{stem}-t1-{phase}-{i}.json').read_text()) for i in range(16)]
        monitor=[json.loads(x) for x in (R/(stem+'-monitor.jsonl')).read_text().splitlines()]
        cached=s['cached_tokens_per_request']
        actual=[x['input_tokens'] for x in records]
        v={
            'requests':s['requests'],'successes':s['successes'],'full_output_requests':s['full_output_budget_requests'],
            'wall_s':s['wall_s'],'aggregate_tok_s':s['aggregate_output_tokens_per_s'],
            'ttft_s':s['ttft_output_s'],'latency_s':s['latency_s'],'server_prefill_s':s['server_prefill_s'],
            'cache_hit_requests':s['cache_hit_requests'],'cached_tokens_total':sum(cached),
            'cached_fraction_of_input':sum(cached)/sum(actual),
            'project_prefix_hit_requests':sum(c>=corpus['users'][i]['phases']['project-cold']['tokens']-10 for i,c in enumerate(cached)) if phase!='decode-control' else 0,
            'external_requests':s['external_requests_estimate'],
            'longest_input_tokens':max(actual),'long_user_ttft_s':records[15]['ttft_output_s'] if phase!='decode-control' else None,
            'min_host_mem_available_gib':min(m['host_memory']['MemAvailable_kb']/2**20 for m in monitor if 'host_memory' in m),
            'max_process_rss_gib':max([m['process_rss_kb']/2**20 for m in monitor if 'process_rss_kb' in m]+[0]),
            'max_swap_used_gib':max((m['host_memory']['SwapTotal_kb']-m['host_memory']['SwapFree_kb'])/2**20 for m in monitor if 'host_memory' in m),
            'swap_out_pages_during_phase':sum(m.get('host_vm_counter_delta',{}).get('pswpout',0) for m in monitor),
            'oom_kills_during_phase':sum(m.get('host_vm_counter_delta',{}).get('oom_kill',0) for m in monitor),
            'cpu_one_core_100_p50':bench.percentile([m['process_cpu_pct_one_core_100'] for m in monitor if 'process_cpu_pct_one_core_100' in m],.5),
            'per_request':[dict(index=i,input_tokens=x['input_tokens'],output_tokens=x['output_tokens'],cached_tokens=cached[i],
                                ttft_s=x['ttft_output_s'],latency_s=x['latency_s'],output_sha256=x['visible_output_sha256'],error=x['error']) for i,x in enumerate(records)],
        }
        variant['phases'][phase]=v
        rows.append({'keep':keep,'phase':phase,**{k:v[k] for k in ['aggregate_tok_s','cached_fraction_of_input','project_prefix_hit_requests','long_user_ttft_s']},
                     'ttft_p50_s':v['ttft_s']['p50'],'ttft_p95_s':v['ttft_s']['p95']})
        if keep!=32:
            base=json.loads((R/f'keep32-{phase}-settings.json').read_text())
            current=json.loads((R/f'{stem}-settings.json').read_text())
            left=[json.loads((R/f'keep32-{phase}-t1-{phase}-{i}.json').read_text()) for i in range(16)]
            pairs.append({'keep':keep,'phase':phase,
                          'request_bodies_match':base['request_bodies']==current['request_bodies'],
                          'equal_visible_outputs':sum(a['visible_output_sha256']==b['visible_output_sha256'] for a,b in zip(left,records)),
                          'count':16,'unequal_indices':[i for i,(a,b) in enumerate(zip(left,records)) if a['visible_output_sha256']!=b['visible_output_sha256']]})
    variants[str(keep)]=variant
output={
    'date':'2026-10-11','engine':'TensorFold Python 0.6.5','commit':'609ca419abecebdc5a059498a613680bd3aa847f',
    'model':'TensorFold/Qwen3.8-Flash-Next-MLX-4bit-MTP','model_revision':'2b170fa6309d5d1ee380b35636075fac7945f286',
    'settings':{'parallel':16,'context':75000,'kv_dtype':'int8','vision':True,'ple_on_ssd':True,'mtp_drafts':6,'mtp_confidence':.60,
                'snapshots_tested':[32,48,64],'source_change':'Only engine.py KEEP constant; planning and runtime use the same value.',
                'original_ssd_batch_patch':True,'request_temperature':0,'server_default_temperature':.1,'thinking_budget':1024,
                'decode_control_max_tokens':512,'conversation_max_tokens':128,'ignore_eos':True},
    'workload':{'users':16,'initial_contexts':[1800]*8+[7400]*7+[65000],
                'sequence':phases,'shared_system_tokens':corpus['shared_system_tokens'],'synthetic_fixed_assistant_history':True},
    'variants':variants,'comparison_rows':rows,'correctness_pairs':pairs,
    'restoration':json.loads((R/'restoration.json').read_text()),
    'limitations':['One matched campaign per variant in 32/48/64 order; no alternated independent trials or significance claim.',
                   'Synthetic programming histories over the OpenAI API, not a full OpenCode tool-use or coding-quality evaluation.',
                   'Only one approximately 65k prompt among 16 users; does not validate sixteen simultaneous full 75k contexts.',
                   'TTFT includes reasoning; SSE chunk gaps are not token inter-token latency.',
                   'No GPU timeline captured; no claim about GPU idle recovered.',
                   'Startup estimate is an admission estimate; host RSS/MemAvailable alone do not describe GB10 unified-memory consumption.',
                   'OS page cache remains intact across variants; the isolated port excludes external inference requests.',
                   'Snapshot-count test changes prefix retention only; n-gram storage remains the SSD path in every arm.'],
    'tools_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'tools').glob('*.py')},
    'prompts_sha256':hashlib.sha256((ROOT/'prompts.json').read_bytes()).hexdigest(),
}
(R/'comparison.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(rows,indent=2));print('Correctness',json.dumps(pairs))
