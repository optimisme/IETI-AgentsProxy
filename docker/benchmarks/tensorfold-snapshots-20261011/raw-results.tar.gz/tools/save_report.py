import hashlib
import json
import re
import shutil
import tarfile
from pathlib import Path

root=Path('/tmp/tensorfold-snapshots-20261011')
dest=Path('/Users/albertpalaciosjimenez/Documents/GitHub/IETI-AgentsProxy/docker/benchmarks/tensorfold-snapshots-20261011')
dest.mkdir(parents=True,exist_ok=True)
p=root/'results/comparison.json';x=json.loads(p.read_text())
assert all(v['request_bodies_match'] and v['equal_visible_outputs']==v['count'] for v in x['correctness_pairs'])
assert all(s['successes']==16 and s['full_output_requests']==16 and s['external_requests']==0 and s['oom_kills_during_phase']==0 for v in x['variants'].values() for s in v['phases'].values())
swaps=[dict(keep=int(k),phase=phase,pages=s['swap_out_pages_during_phase']) for k,v in x['variants'].items() for phase,s in v['phases'].items() if s['swap_out_pages_during_phase']]
x['summary']={
    'measured_requests':288,'warmup_requests':48,'equal_output_pairs_vs_keep32':192,
    'all_measured_requests_completed':True,'global_swap_out_events':swaps,
    'swap_note':'Host-wide counters: two pages swapped out during KEEP32 cold-context phase; zero sampled page-outs in all other measured phases. Not necessarily attributable to TensorFold.',
    'recommendation':'64 snapshots is the strongest tested option for branching to an earlier turn; 32 already gives full reuse for normal append-only continuations.',
    'additional_startup_estimate_gib_64_vs_32':round(x['variants']['64']['startup_estimate_gib']-x['variants']['32']['startup_estimate_gib'],2),
    'deployment_changed_permanently':False,
    'restored_deployment':'EXL3 3.05, KV int8, vision, parallel16, context75000, KEEP32; preserved original MLX container stopped intact.',
    'restored_engine_sha256':'c861e077c91f701cf41d41f5dc1848d34dce21e9edb250b7f3d99b33920017e4',
    'local_and_remote_recipes_unchanged':True,
    'recipes_sha256':{'MLX':'e195dc49d4fdb4dd99a861e9b00516643247d79787622d3487834ced41474768','EXL3':'ce7b29879359e02d3fa471dccec8d6031c881f17976124c1a22209eae2b1a92d'},
    'raw_remote':'~/tensorfold-snapshots-20261011/',
    'patch_note':'Saved diffs apply to the current KEEP32 patched engine. Production YAML remains unchanged and still validates snapshot values only through 32; deploying 48/64 also requires extending its validated range and documentation.',
}
x['tools_sha256']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'tools').glob('*.py')}
p.write_text(json.dumps(x,indent=2)+'\n')
for k in (48,64):shutil.copy2(root/f'keep32-to-{k}.patch',dest/f'keep32-to-{k}.patch')
archive=dest/'raw-results.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for dirname in ('results','tools'):
        t.add(root/dirname,arcname=dirname,filter=lambda info:None if '__pycache__' in info.name else info)
    for name in ('prompts.json','controller.log','keep32-to-48.patch','keep32-to-64.patch'):
        t.add(root/name,arcname=name)
with tarfile.open(archive) as t:
    matches=[]
    for member in t.getmembers():
        if member.isfile() and re.search(rb'(?:hf_[A-Za-z0-9]{20,}|ieti_sk_[A-Za-z0-9_-]{16,}|sk-[A-Za-z0-9_-]{24,})',t.extractfile(member).read()):
            matches.append(member.name)
    assert not matches,matches
x['raw_archive']={'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'private_container_inspects_excluded':True}
(dest/'results.json').write_text(json.dumps(x,indent=2)+'\n')
print('Saved',dest)
print('Archive bytes',archive.stat().st_size)
print('Swap events',swaps)
