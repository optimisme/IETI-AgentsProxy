"""Matched 16-user prefix retention workload; standard-library SSE transport."""
import argparse
import concurrent.futures
import hashlib
import json
import threading
import time
from pathlib import Path
from types import SimpleNamespace

import bench_long_context as bench

def cohort(args, phase, bodies, targets=None):
    tag=f'keep{args.keep}-{phase}'
    opts=SimpleNamespace(base_url=args.base_url,run_tag=tag,trial=1,variant=f'keep{args.keep}',pair_set='snapshot-32-48-64',
                         workload=phase,max_tokens=bodies[0]['max_tokens'],api_key_env=None,timeout=1200,pid=args.pid,
                         monitor_interval=1.0,no_gpu_monitor=True)
    specs=[]
    for i,body in enumerate(bodies):
        prompt=json.dumps(body['messages'],sort_keys=True,separators=(',',':'))
        specs.append(dict(index=i,workload=phase,prompt=prompt,body=body,prompt_sha256=bench.sha(prompt),
                          request_body_sha256=bench.sha(body),prompt_chars=len(prompt),
                          prompt_tokens_target=targets[i] if targets else None))
    before=bench.fetch_json(args.base_url,'/health')
    gate=threading.Barrier(len(specs));cancel=threading.Event();lock=threading.Lock()
    bench.atomic_json(args.outdir/(tag+'-settings.json'),dict(keep=args.keep,phase=phase,request_bodies=bodies,prompt_manifest=specs,
                     benchmark_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
    stopped=threading.Event();mon=threading.Thread(target=bench.monitor,args=(opts,args.outdir,stopped),daemon=True);mon.start()
    try:
        with (args.outdir/(tag+'-markers.jsonl')).open('w') as markers:
            started=time.monotonic()
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(specs)) as pool:
                futures=[pool.submit(bench.request_one,opts,s,args.outdir,gate,None,cancel,markers,lock) for s in specs]
                records=[f.result() for f in futures]
            wall=time.monotonic()-started
    finally:
        stopped.set();mon.join(timeout=5)
    after=bench.fetch_json(args.base_url,'/health');summary=bench.summarize(records,wall)
    cached=[r.get('cached_tokens') if r.get('cached_tokens') is not None else (r.get('tensorfold_stats') or {}).get('cached',0) for r in records]
    summary.update(phase=phase,keep=args.keep,health_before=before,health_after=after,
                   cache_hit_requests=sum(v>0 for v in cached),cached_tokens_total=sum(cached),cached_tokens_per_request=cached,
                   external_requests_estimate=after['requests_total']-before['requests_total']-len(records))
    bench.atomic_json(args.outdir/(tag+'-summary.json'),summary)
    print(json.dumps({'keep':args.keep,'phase':phase,'successes':summary['successes'],'tok_s':round(summary['aggregate_output_tokens_per_s'],2),
                      'ttft_p50':summary['ttft_output_s']['p50'],'ttft_p95':summary['ttft_output_s']['p95'],
                      'cache_hit_requests':summary['cache_hit_requests'],'cached_tokens_total':summary['cached_tokens_total'],
                      'external_requests':summary['external_requests_estimate']}),flush=True)
    if summary['successes']!=len(records) or summary['full_output_budget_requests']!=len(records):
        raise RuntimeError('Incomplete requests: '+tag)
    return records

def main():
    p=argparse.ArgumentParser();p.add_argument('--keep',type=int,required=True);p.add_argument('--outdir',type=Path,required=True)
    p.add_argument('--manifest',type=Path,required=True);p.add_argument('--base-url',default='http://127.0.0.1:18000');p.add_argument('--pid',type=int)
    args=p.parse_args();args.outdir.mkdir(parents=True,exist_ok=True)
    corpus=json.loads(args.manifest.read_text())
    def bodies(messages,max_tokens):
        return [{'model':'TensorFold/Qwen3.8-Flash-Next-MLX-4bit-MTP','messages':m,'stream':True,'ignore_eos':True,
                 'max_tokens':max_tokens,'temperature':0,'top_p':0.95,'stream_options':{'include_usage':True}} for m in messages]
    warm=[[{'role':'user','content':f'Snapshot warmup {i}. '+bench.INSTRUCTION}] for i in range(16)]
    cohort(args,'warmup',bodies(warm,64))
    cold=[[{'role':'user','content':f'Snapshot control {i}. '+bench.INSTRUCTION}] for i in range(16)]
    cohort(args,'decode-control',bodies(cold,512))
    for phase in ['project-cold','growth-1','growth-2','branch-previous','branch-continue']:
        cohort(args,phase,bodies([u['phases'][phase]['messages'] for u in corpus['users']],128),
               [u['phases'][phase]['tokens'] for u in corpus['users']])

if __name__=='__main__': main()
