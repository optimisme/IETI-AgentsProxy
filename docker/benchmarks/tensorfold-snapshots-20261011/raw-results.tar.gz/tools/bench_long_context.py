#!/usr/bin/env python3
"""Standalone, standard-library SSE campaign client; never modifies a server.

Derived from tensorfold-ssd-16stream-followup/tools/bench.py. Timing begins when
each HTTP request is sent. TTFT includes reasoning. Chunk gaps are NOT token ITL.
Use --dry-run to freeze/check prompts without sending any HTTP requests.
"""
import argparse
import concurrent.futures
import hashlib
import json
import math
import os
import random
import signal
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

WORDS = ('amber bridge cedar delta ember forest garden harbor island juniper kettle lantern meadow north ocean pebble quartz river silver timber upland valley willow xenon yellow zephyr').split()
CHAR_BUDGETS = {7400: 32768, 16000: 71300, 32000: 143500}
INSTRUCTION = ('Print a very long numbered list of distinct practical observations, one sentence per item, '
               'about organizing a school science laboratory. Continue for at least 3000 items. '
               'Do not summarize, conclude, ask questions, or discuss these instructions. Start the list immediately.')


def sha(value):
    if not isinstance(value, bytes):
        value = value.encode() if isinstance(value, str) else json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(value).hexdigest()


def percentile(values, q):
    values = sorted(v for v in values if isinstance(v, (float, int)) and math.isfinite(v))
    if not values:
        return None
    pos = (len(values)-1)*q
    lo, hi = math.floor(pos), math.ceil(pos)
    return values[lo] + (values[hi]-values[lo])*(pos-lo)


def describe(values):
    values = [v for v in values if isinstance(v, (float, int)) and math.isfinite(v)]
    return {'n': len(values), 'min': min(values) if values else None, 'max': max(values) if values else None,
            'mean': sum(values)/len(values) if values else None,
            **{f'p{int(q*100)}': percentile(values, q) for q in [.5, .95, .99]}}


def fetch_json(base, path, timeout=5):
    try:
        with urllib.request.urlopen(base + path, timeout=timeout) as response:
            return json.load(response)
    except Exception as exc:
        return {'probe_error': str(exc), 'path': path}


def atomic_json(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(path)


def prompt_for(workload, seed, trial, index, chars):
    # The FIRST user bytes differ across all streams/cohorts/trials. No common
    # instructions before the nonce. Matched A/B intentionally replays this body.
    nonce = sha(f'{seed}|{trial}|{index}')[:32]
    first = f'{nonce}; independent request {index}. '
    if workload == 'decode':
        return first + INSTRUCTION
    rng = random.Random(f'{seed}|{trial}|{index}|prefill')
    rows = []
    size = 0
    while size < chars:
        row = f'Record {len(rows)+1}: ' + ' '.join(rng.choice(WORDS) for _ in range(24)) + '.\n'
        rows.append(row)
        size += len(row)
    return first + 'Read this complete set of field notes carefully.\n' + ''.join(rows)[:chars] + '\n' + INSTRUCTION


def freeze_prompts(args):
    target = args.prompt_tokens
    chars = args.prompt_chars if args.prompt_chars is not None else CHAR_BUDGETS.get(target, round(target*4.48))
    seed = f'{args.prompt_seed}:{args.workload}:{target if args.workload != "decode" else "short"}'
    tokenizer = None
    if args.tokenizer_json:
        # Optional use of an ALREADY INSTALLED package, never install/download.
        from tokenizers import Tokenizer
        tokenizer = Tokenizer.from_file(str(args.tokenizer_json))
    specs = []
    for index in range(args.n):
        kind = 'decode' if args.workload == 'decode' or (args.workload == 'mixed' and index < args.n//2) else 'prefill'
        prompt = prompt_for(kind, seed, args.trial, index, chars)
        local_count = None
        if tokenizer and kind == 'prefill':
            # Content count + known template overhead is a sizing aid. usage
            # prompt_tokens is authoritative, including the actual chat template.
            lo, hi = 0, max(chars*2, 1024)
            corpus = prompt_for(kind, seed, args.trial, index, hi)
            prefix = corpus.index('Record 1:')
            suffix = '\n' + INSTRUCTION
            while lo < hi:
                mid = (lo+hi)//2
                candidate = corpus[:prefix] + corpus[prefix:prefix+mid] + suffix
                count = len(tokenizer.encode(candidate).ids) + args.chat_overhead_tokens
                if count < target:
                    lo = mid+1
                else:
                    hi = mid
            prompt = corpus[:prefix] + corpus[prefix:prefix+lo] + suffix
            local_count = len(tokenizer.encode(prompt).ids) + args.chat_overhead_tokens
        generation_seed = int(sha(f'{seed}|{args.trial}|{index}|generation')[:8], 16) % (2**31)
        body = {'model': args.model, 'messages': [{'role': 'user', 'content': prompt}],
                'stream': True, 'max_tokens': args.max_tokens, 'ignore_eos': True,
                'temperature': args.temperature, 'top_p': args.top_p,
                'stream_options': {'include_usage': True}}
        if not args.omit_generation_seed:
            body['seed'] = generation_seed
        if not args.omit_top_k:
            body['top_k'] = args.top_k
        specs.append({'index': index, 'workload': kind, 'prompt': prompt, 'body': body,
                      'prompt_sha256': sha(prompt), 'request_body_sha256': sha(body),
                      'prompt_chars': len(prompt), 'prompt_tokens_target': target if kind == 'prefill' else None,
                      'prompt_tokens_local': local_count, 'generation_seed': generation_seed,
                      'normalized_prompt_seed': seed})
    return specs


def monitor(args, outdir, stopped):
    last_pid = last_cpu = last_vm = last_time = None
    hz = os.sysconf('SC_CLK_TCK') if hasattr(os, 'sysconf') else 100
    with (outdir/(args.run_tag+'-monitor.jsonl')).open('w') as target:
        while not stopped.is_set():
            now = time.monotonic()
            item = {'unix_ns': time.time_ns(), 'monotonic_ns': time.monotonic_ns(),
                    'health': fetch_json(args.base_url, '/health', timeout=2)}
            try:
                mem = {}
                for line in Path('/proc/meminfo').read_text().splitlines():
                    key, value = line.split(':', 1)
                    if key in ('MemTotal', 'MemFree', 'MemAvailable', 'Buffers', 'Cached', 'SwapTotal', 'SwapFree', 'Dirty', 'Slab'):
                        mem[key+'_kb'] = int(value.split()[0])
                item['host_memory'] = mem
                cpu = [int(v) for v in Path('/proc/stat').read_text().splitlines()[0].split()[1:9]]
                if last_cpu is not None:
                    delta = [b-a for a, b in zip(last_cpu, cpu)]
                    item['host_cpu_busy_pct'] = 100*(sum(delta)-delta[3]-delta[4])/sum(delta) if sum(delta) else 0
                    item['host_cpu_iowait_pct'] = 100*delta[4]/sum(delta) if sum(delta) else 0
                last_cpu = cpu
                vm = {key: int(value) for line in Path('/proc/vmstat').read_text().splitlines()
                      for key, value in [line.split()] if key in ('pswpin', 'pswpout', 'pgmajfault', 'oom_kill')}
                item['host_vm_counters'] = vm
                if last_vm is not None:
                    item['host_vm_counter_delta'] = {k: vm[k]-last_vm[k] for k in vm.keys() & last_vm.keys()}
                last_vm = vm
                if args.pid:
                    stat = Path(f'/proc/{args.pid}/stat').read_text().rsplit(')', 1)[1].split()
                    ticks = int(stat[11])+int(stat[12])
                    item['process_rss_kb'] = int(stat[21])*os.sysconf('SC_PAGE_SIZE')/1024
                    item['process_thread_count'] = int(stat[17])
                    item['process_cpu_ticks'] = ticks
                    if last_pid is not None and last_time is not None:
                        item['process_cpu_pct_one_core_100'] = 100*(ticks-last_pid)/hz/(now-last_time)
                    last_pid = ticks
                    for name in ['io', 'status']:
                        try:
                            lines = Path(f'/proc/{args.pid}/{name}').read_text().splitlines()
                            item['process_'+name] = {k: int(v.split()[0]) for line in lines if ':' in line
                                                       for k, v in [line.split(':', 1)]
                                                       if name == 'io' or k in ('VmRSS', 'VmSwap', 'VmHWM')}
                        except (OSError, ValueError) as exc:
                            item['process_'+name+'_error'] = str(exc)
            except Exception as exc:
                item['proc_error'] = str(exc)
            last_time = now
            if not args.no_gpu_monitor:
                for name, query in [('gpu_csv', '--query-gpu=utilization.gpu,utilization.memory,memory.used,memory.total,temperature.gpu,power.draw,clocks.sm,clocks.mem'),
                                    ('compute_apps_csv', '--query-compute-apps=pid,used_gpu_memory')]:
                    try:
                        result = subprocess.run(['nvidia-smi', query, '--format=csv,noheader,nounits'], capture_output=True, text=True, timeout=3)
                        item[name] = result.stdout.strip()
                        if result.returncode:
                            item[name+'_error'] = result.stderr.strip()
                    except Exception as exc:
                        item[name+'_error'] = str(exc)
            target.write(json.dumps(item)+'\n')
            target.flush()
            stopped.wait(max(.01, args.monitor_interval-(time.monotonic()-now)))


class MixedGate:
    def __init__(self, n, stagger):
        self.expected = n//2
        self.stagger = stagger
        self.lock = threading.Lock()
        self.decoding = set()
        self.failed = threading.Event()
        self.ready = threading.Event()
        self.long_gate = threading.Barrier(n//2)
        self.ready_ns = None

    def first_output(self, index):
        with self.lock:
            self.decoding.add(index)
            if len(self.decoding) == self.expected:
                self.ready_ns = time.monotonic_ns()
                self.ready.set()

    def wait(self, timeout, cancelled):
        until = time.monotonic()+timeout
        while not self.ready.wait(.1):
            if self.failed.is_set() or cancelled.is_set():
                raise RuntimeError('Mixed decoders failed/cancelled before all first outputs')
            if time.monotonic() >= until:
                raise TimeoutError('Mixed release timeout waiting for every decoder first output')
        if self.failed.is_set() or cancelled.is_set():
            raise RuntimeError('Mixed cancelled before long request release')
        if cancelled.wait(max(0, self.stagger-(time.monotonic_ns()-self.ready_ns)/1e9)):
            raise RuntimeError('Mixed cancelled during stagger')
        self.long_gate.wait(timeout=timeout)


def request_one(args, spec, outdir, gate, mixed, cancelled, markers, lock):
    request_id = f'{args.run_tag}-t{args.trial}-{spec["workload"]}-{spec["index"]}'
    record = {k: v for k, v in spec.items() if k not in ('prompt', 'body')}
    record.update({'request_id': request_id, 'trial': args.trial, 'variant': args.variant, 'pair_set': args.pair_set,
                   'cohort': args.workload, 'max_tokens': args.max_tokens, 'usage': None,
                   'tensorfold_stats': None, 'chunks': [], 'finish_reason': None, 'error': None,
                   'done_received': False, 'start_unix_ns': None, 'start_monotonic_ns': None})
    content, reasoning = [], []
    first = first_content = first_reasoning = last = None
    def mark(event, **extra):
        with lock:
            markers.write(json.dumps({'event': event, 'request_id': request_id, 'unix_ns': time.time_ns(),
                                       'monotonic_ns': time.monotonic_ns(), **extra})+'\n')
            markers.flush()
    def event(data):
        nonlocal first, first_content, first_reasoning, last
        if data == '[DONE]':
            record['done_received'] = True
            return
        now = time.monotonic_ns()
        payload = json.loads(data)
        if payload.get('error'):
            raise RuntimeError(str(payload['error']))
        if payload.get('usage') is not None:
            record['usage'] = payload['usage']
        if payload.get('tensorfold') is not None:
            record['tensorfold_stats'] = payload['tensorfold']
        for choice in payload.get('choices', []):
            delta = choice.get('delta') or {}
            text = delta.get('content') or ''
            thought = delta.get('reasoning_content') or delta.get('reasoning') or ''
            if choice.get('finish_reason') is not None:
                record['finish_reason'] = choice['finish_reason']
            if not isinstance(text, str) or not isinstance(thought, str):
                raise ValueError('Nonstring SSE text delta')
            if text or thought:
                if first is None:
                    first = now
                    mark('first_generated_output', workload=spec['workload'])
                    if mixed and spec['workload'] == 'decode':
                        mixed.first_output(spec['index'])
                if text and first_content is None:
                    first_content = now
                if thought and first_reasoning is None:
                    first_reasoning = now
                last = now
                content.append(text)
                reasoning.append(thought)
                record['chunks'].append({'offset_ns': now-record['start_monotonic_ns'],
                                          'content_chars': len(text), 'reasoning_chars': len(thought)})
    response = None
    try:
        gate.wait(timeout=args.timeout)
        if mixed and spec['workload'] == 'prefill':
            mixed.wait(args.mixed_release_timeout, cancelled)
        if cancelled.is_set():
            raise RuntimeError('Campaign cancelled before HTTP send')
        headers = {'Content-Type': 'application/json', 'X-Request-ID': request_id}
        key = os.environ.get(args.api_key_env, '') if args.api_key_env else ''
        if key:
            headers['Authorization'] = 'Bearer ' + key
        req = urllib.request.Request(args.base_url+'/v1/chat/completions', data=json.dumps(spec['body']).encode(), headers=headers)
        record['start_unix_ns'] = time.time_ns()
        record['start_monotonic_ns'] = time.monotonic_ns()
        mark('request_start', workload=spec['workload'])
        response = urllib.request.urlopen(req, timeout=args.timeout)
        record['http_status'] = response.status
        data_lines = []
        for raw in response:
            if cancelled.is_set():
                raise RuntimeError('Campaign cancelled during SSE')
            line = raw.decode('utf-8', errors='replace').rstrip('\r\n')
            if not line:
                if data_lines:
                    event('\n'.join(data_lines))
                    data_lines = []
            elif line.startswith('data:'):
                data_lines.append(line[5:].lstrip())
        if data_lines:
            event('\n'.join(data_lines))
        if not record['done_received'] or record['finish_reason'] is None or record['usage'] is None:
            raise RuntimeError('Incomplete SSE: expected DONE, finish_reason, and exact usage')
    except Exception as exc:
        record['error'] = str(exc)
        if isinstance(exc, urllib.error.HTTPError):
            record['http_status'] = exc.code
            record['error_body'] = exc.read(8192).decode('utf-8', errors='replace')
        if mixed and spec['workload'] == 'decode' and first is None:
            mixed.failed.set()
    finally:
        if response is not None:
            response.close()
    end = time.monotonic_ns()
    start = record['start_monotonic_ns']
    record.update({'end_unix_ns': time.time_ns(), 'end_monotonic_ns': end,
                   'first_output_monotonic_ns': first, 'last_output_monotonic_ns': last,
                   'latency_s': (end-start)/1e9 if start is not None else None,
                   'ttft_output_s': (first-start)/1e9 if first is not None else None,
                   'ttft_content_s': (first_content-start)/1e9 if first_content is not None else None,
                   'ttft_reasoning_s': (first_reasoning-start)/1e9 if first_reasoning is not None else None,
                   'output_window_s': (last-first)/1e9 if last is not None else None,
                   'content': ''.join(content), 'reasoning': ''.join(reasoning)})
    record['content_sha256'] = sha(record['content'])
    record['reasoning_sha256'] = sha(record['reasoning'])
    record['visible_output_sha256'] = sha({'content': record['content'], 'reasoning': record['reasoning']})
    usage = record['usage'] or {}
    record['output_tokens'] = usage.get('completion_tokens', usage.get('output_tokens'))
    record['input_tokens'] = usage.get('prompt_tokens', usage.get('input_tokens'))
    record['cached_tokens'] = (usage.get('prompt_tokens_details') or {}).get('cached_tokens')
    record['reasoning_tokens'] = (usage.get('completion_tokens_details') or {}).get('reasoning_tokens')
    record['prompt_tokens_target_error_pct'] = 100*(record['input_tokens']/spec['prompt_tokens_target']-1) if record['input_tokens'] is not None and spec['prompt_tokens_target'] else None
    count, span = record['output_tokens'], record['output_window_s']
    record['tpot_ms_approx'] = span*1000/(count-1) if count and count > 1 and span else None
    record['decode_tokens_per_s_approx'] = (count-1)/span if count and count > 1 and span else None
    record['server_prefill_s'] = (record['tensorfold_stats'] or {}).get('prefill_s')
    record['chunk_interarrival_ms'] = [(b['offset_ns']-a['offset_ns'])/1e6 for a, b in zip(record['chunks'], record['chunks'][1:])]
    record['full_output_budget'] = record['error'] is None and count == args.max_tokens
    mark('request_end', workload=spec['workload'], error=record['error'], output_tokens=count)
    atomic_json(outdir/(request_id+'.json'), record)
    return record


def summarize(records, wall_s):
    good = [r for r in records if r['error'] is None]
    exact_input = bool(good) and all(isinstance(r['input_tokens'], int) for r in good)
    exact_output = bool(good) and all(isinstance(r['output_tokens'], int) for r in good)
    firsts = [r['first_output_monotonic_ns'] for r in good if r['first_output_monotonic_ns'] is not None]
    starts = [r['start_monotonic_ns'] for r in good if r['start_monotonic_ns'] is not None]
    prefill_wall = (max(firsts)-min(starts))/1e9 if firsts and starts else None
    # This TTFT wall rate INCLUDES scheduling/queueing and first decode, unlike
    # kernel-only prefill. Server prefill_s is per-stream service time, not wall.
    summary = {'requests': len(records), 'successes': len(good), 'wall_s': wall_s,
               'full_output_budget_requests': sum(r['full_output_budget'] for r in records),
               'input_tokens_total': sum(r['input_tokens'] for r in good) if exact_input else None,
               'output_tokens_total': sum(r['output_tokens'] for r in good) if exact_output else None,
               'aggregate_prompt_tokens_per_s': sum(r['input_tokens'] for r in good)/wall_s if exact_input and wall_s else None,
               'aggregate_output_tokens_per_s': sum(r['output_tokens'] for r in good)/wall_s if exact_output and wall_s else None,
               'prefill_ttft_window_s': prefill_wall,
               'prefill_prompt_tokens_per_s_ttft_window': sum(r['input_tokens'] for r in good)/prefill_wall if exact_input and prefill_wall else None,
               'all_cache_counts_zero': len(good) == len(records) and all(r['cached_tokens'] == 0 for r in good),
               'request_errors': [{'request_id': r['request_id'], 'error': r['error']} for r in records if r['error']],
               'quantile_note': 'Empirical request quantiles (16 samples/cohort). SSE chunk gaps are not token ITL.',
               'prefill_rate_note': 'TTFT-window prompt throughput includes scheduler queues and first generated output; not kernel-only prefill throughput.'}
    for field in ['input_tokens', 'output_tokens', 'prompt_tokens_target_error_pct', 'ttft_output_s', 'ttft_content_s', 'ttft_reasoning_s', 'latency_s', 'tpot_ms_approx', 'decode_tokens_per_s_approx', 'server_prefill_s']:
        summary[field] = describe([r.get(field) for r in good])
    summary['sse_chunk_interarrival_ms'] = describe([v for r in good for v in r['chunk_interarrival_ms']])
    summary['per_request'] = [{k: r[k] for k in ['request_id', 'workload', 'index', 'prompt_tokens_target', 'input_tokens', 'output_tokens', 'latency_s', 'ttft_output_s', 'tpot_ms_approx', 'error']} for r in records]
    return summary


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base-url', default='http://127.0.0.1:8000')
    p.add_argument('--model')
    p.add_argument('--workload', choices=['decode', 'prefill', 'mixed'], default='prefill')
    p.add_argument('--n', type=int, default=16)
    p.add_argument('--trial', type=int, default=0)
    p.add_argument('--run-tag', required=True)
    p.add_argument('--prompt-seed', default='longctx-20261005')
    p.add_argument('--variant', required=True)
    p.add_argument('--pair-set', default='final-longctx')
    p.add_argument('--outdir', required=True, type=Path)
    p.add_argument('--max-tokens', type=int, default=512)
    p.add_argument('--prompt-tokens', type=int, default=7400, help='Nominal long-prompt target. Exact server usage is recorded.')
    p.add_argument('--prompt-chars', type=int, help='Override deterministic corpus characters (32768, 71300, 143500 defaults).')
    p.add_argument('--tokenizer-json', type=Path, help='Optional local tokenizer JSON; requires tokenizers already installed.')
    p.add_argument('--chat-overhead-tokens', type=int, default=0, help='Known chat-template overhead, only for optional tokenizer sizing.')
    p.add_argument('--temperature', type=float, default=.1)
    p.add_argument('--top-p', type=float, default=.95)
    p.add_argument('--top-k', type=int, default=20)
    p.add_argument('--omit-top-k', action='store_true', help='Use only after confirming server schema omits this parameter.')
    p.add_argument('--omit-generation-seed', action='store_true', help='Use if this server lacks request seed support; preserve prompt equality and record limitation.')
    p.add_argument('--mixed-stagger', type=float, default=2.0)
    p.add_argument('--mixed-release-timeout', type=float, default=120)
    p.add_argument('--timeout', type=float, default=1800)
    p.add_argument('--api-key-env')
    p.add_argument('--pid', type=int, help='Server PID as visible from this client /proc namespace.')
    p.add_argument('--monitor-interval', type=float, default=1.0)
    p.add_argument('--no-monitor', action='store_true')
    p.add_argument('--no-gpu-monitor', action='store_true')
    p.add_argument('--dry-run', action='store_true', help='Write prompt manifest only; makes zero HTTP calls.')
    p.add_argument('--save-prompts', action='store_true', help='Include synthetic prompts in the freeze manifest.')
    p.add_argument('--generation-manifest', type=Path, help='Snapshot JSON for current fresh server generation, argv/source hashes.')
    a = p.parse_args()
    if a.n < 1 or a.max_tokens < 1 or a.prompt_tokens < 1 or a.monitor_interval <= 0 or a.timeout <= 0:
        p.error('n, max-tokens, prompt-tokens, monitor-interval, timeout must be positive')
    if a.workload == 'mixed' and a.n % 2:
        p.error('mixed n must be even (8 decode + 8 long at n=16)')
    a.base_url = a.base_url.rstrip('/')
    a.outdir.mkdir(parents=True, exist_ok=True)
    summary_path = a.outdir/(a.run_tag+'-summary.json')
    if summary_path.exists() or (a.outdir/(a.run_tag+'-settings.json')).exists():
        p.error('run-tag already exists; use a fresh tag to preserve prior measurements')
    if not a.model:
        if a.dry_run:
            a.model = 'TensorFold/Qwen3.8-Flash-Next-MLX-4bit-MTP'
        else:
            a.model = fetch_json(a.base_url, '/v1/models')['data'][0]['id']
    specs = freeze_prompts(a)
    manifest = {k: str(v) if isinstance(v, Path) else v for k, v in vars(a).items()}
    manifest.update({'schema': 'long-context-benchmark-v1', 'client_sha256': sha(Path(__file__).read_bytes()),
                     'first_32_user_chars_unique': len({s['prompt'][:32] for s in specs}) == len(specs),
                     'prompt_manifest': [{k: v for k, v in s.items() if k not in ('body', 'prompt') or (k == 'prompt' and a.save_prompts)} for s in specs]})
    if a.generation_manifest:
        manifest['generation_manifest'] = json.loads(a.generation_manifest.read_text())
    atomic_json(a.outdir/(a.run_tag+'-settings.json'), manifest)
    if a.dry_run:
        print(json.dumps({'dry_run': True, 'settings_path': str(a.outdir/(a.run_tag+'-settings.json')), 'requests': len(specs), 'unique_prefixes': manifest['first_32_user_chars_unique']}))
        return 0
    stopped = threading.Event()
    cancelled = threading.Event()
    def cancel(signum, _frame):
        cancelled.set()
        print(json.dumps({'cancelled_signal': signum, 'note': 'HTTP streams close at their next read; server supervisor owns GPU process cleanup.'}), flush=True)
    signal.signal(signal.SIGTERM, cancel)
    signal.signal(signal.SIGINT, cancel)
    monitor_thread = None
    records = []
    before = fetch_json(a.base_url, '/health')
    if before.get('requests_running') not in (None, 0):
        raise RuntimeError('Refusing cohort while server reports active requests')
    if not a.no_monitor:
        monitor_thread = threading.Thread(target=monitor, args=(a, a.outdir, stopped), daemon=True)
        monitor_thread.start()
    start = time.monotonic()
    start_unix_ns = time.time_ns()
    mixed = MixedGate(a.n, a.mixed_stagger) if a.workload == 'mixed' else None
    try:
        with (a.outdir/(a.run_tag+'-markers.jsonl')).open('w') as markers:
            lock = threading.Lock()
            gate = threading.Barrier(a.n)
            with concurrent.futures.ThreadPoolExecutor(max_workers=a.n) as pool:
                futures = [pool.submit(request_one, a, s, a.outdir, gate, mixed, cancelled, markers, lock) for s in specs]
                records = [future.result() for future in futures]
    finally:
        stopped.set()
        if monitor_thread:
            monitor_thread.join(timeout=12)
    wall_s = time.monotonic()-start
    after = fetch_json(a.base_url, '/health')
    summary = summarize(records, wall_s)
    summary.update({'settings': manifest, 'trial': a.trial, 'start_unix_ns': start_unix_ns,
                     'health_before': before, 'health_after': after,
                     'cohorts': {kind: summarize([r for r in records if r['workload'] == kind], wall_s)
                                 for kind in sorted({r['workload'] for r in records})}})
    if mixed:
        decoders = [r for r in records if r['workload'] == 'decode']
        longs = [r for r in records if r['workload'] == 'prefill']
        summary['mixed_release'] = {'expected_decode_first_outputs': mixed.expected,
                                     'observed_decode_first_outputs': len(mixed.decoding), 'ready_monotonic_ns': mixed.ready_ns,
                                     'all_long_requests_overlap_every_decoder': all(r['start_monotonic_ns'] is not None and r['start_monotonic_ns'] < min(d['end_monotonic_ns'] for d in decoders) for r in longs)}
    atomic_json(summary_path, summary)
    print(json.dumps({'summary_path': str(summary_path), **{k: v for k, v in summary.items() if k not in ('settings', 'per_request', 'cohorts', 'health_before', 'health_after')}}), flush=True)
    return 0 if len(records) == a.n and all(r['full_output_budget'] for r in records) and summary['all_cache_counts_zero'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
