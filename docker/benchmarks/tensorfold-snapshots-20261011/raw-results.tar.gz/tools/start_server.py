"""Run the preserved MLX deployment with exactly one source constant changed."""
import hashlib
import json
import os
import re
from pathlib import Path

keep = int(os.environ['SNAPSHOT_TEST_KEEP'])
assert keep in (32, 48, 64)
installed = Path('/opt/tensorfold-venv/lib/python3.12/site-packages/tensorfold')
checkout = Path('/opt/tensorfold-source/src/tensorfold')
expected = 'c861e077c91f701cf41d41f5dc1848d34dce21e9edb250b7f3d99b33920017e4'
sources = {}
for root in (installed, checkout):
    path = root/'families/qwen4_exp/cuda/engine.py'
    before = path.read_bytes()
    assert hashlib.sha256(before).hexdigest() == expected, str(path)
    source = before.decode()
    lines = re.findall(r'^KEEP\s*=.*', source, re.MULTILINE)
    assert len(lines) == 1 and lines[0].startswith('KEEP = 32 '), lines
    for needle in ('indexed_stream_geometry(text, streams + int(graphs and mtp), each, KEEP, mtp=mtp,',
                   'confidence=self.confidence, keep=KEEP, points=self.points,'):
        assert source.count(needle) == 1
    replacement = re.sub(r'^KEEP = 32 ', f'KEEP = {keep} ', source, count=1, flags=re.MULTILINE)
    path.write_text(replacement)
    sources[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
forward = installed/'families/qwen4_exp/cuda/forward.py'
assert hashlib.sha256(forward.read_bytes()).hexdigest() == 'fa06db912a4d02437875a7e146f1ccf4daf36fcf1093df9b50caf9ea316b03bf'
print('[snapshot-test] '+json.dumps({'KEEP':keep, 'engine_hashes':sources,'ssd_patch_unchanged':True}), flush=True)
model = '/root/.cache/huggingface/hub/models--TensorFold--Qwen3.8-Flash-Next-MLX-4bit-MTP/snapshots/2b170fa6309d5d1ee380b35636075fac7945f286'
assert Path(model, 'config.json').exists()
args = ['/opt/tensorfold-venv/bin/tensorfold', 'serve', model, '--backend','cuda', '--host','0.0.0.0', '--port','8000',
        '--name','TensorFold/Qwen3.8-Flash-Next-MLX-4bit-MTP', '--context','75000', '--parallel','16', '--thinking',
        '--reasoning-effort','low', '--thinking-budget','1024', '--temperature','0.1', '--kv-dtype','int8', '--ple-on-ssd',
        '--vision', '--mtp-drafts','6', '--mtp-confidence','0.60', '--no-update-check']
print('[snapshot-test] command '+json.dumps(args), flush=True)
os.execv(args[0],args)
