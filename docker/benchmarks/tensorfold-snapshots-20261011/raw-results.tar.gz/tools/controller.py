"""Isolated sequential A/B/C campaign; restores the original active container."""
import json
import signal
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT=Path.home()/'tensorfold-snapshots-20261011';RESULTS=ROOT/'results';RESULTS.mkdir(exist_ok=True)
ACTIVE='qwen38_flash_next_cuda_vram128_tensorfold_exl3_305_mtp_int8_ssd_vision'
ORIGINAL='qwen38_flash_next_cuda_vram128_tensorfold_mlx_4bit_mtp_int8_ssd_vision'
TEST='tensorfold_snapshot_cache_ab_2226'
IMAGE='ieti/tensorfold-before-exl3:20261011'
def run(args,**kw):return subprocess.run(args,check=True,text=True,**kw)
def capture(args):return subprocess.check_output(args,text=True).strip()
def health(port):
    with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=5) as r:return json.load(r)
def wait_ready(name,port,limit):
    until=time.monotonic()+limit;last=0
    while time.monotonic()<until:
        if capture(['docker','inspect','--format','{{.State.Running}}',name])!='true':
            raise RuntimeError('Container stopped: '+name)
        try:
            h=health(port)
            if h.get('ok'):return h
        except Exception:pass
        if time.monotonic()-last>30:
            print('Loading',name,'at',time.strftime('%H:%M:%S'),flush=True);last=time.monotonic()
        time.sleep(5)
    raise TimeoutError('Model startup did not become healthy: '+name)
def inventory():
    return {n:json.loads(capture(['docker','inspect','--format','{{json .State}}',n])) for n in (ACTIVE,ORIGINAL)}
def restore():
    if subprocess.run(['docker','inspect',TEST],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:
        subprocess.run(['docker','stop','-t','60',TEST],stdout=subprocess.DEVNULL)
        subprocess.run(['docker','rm',TEST],stdout=subprocess.DEVNULL)
    if capture(['docker','inspect','--format','{{.State.Running}}',ACTIVE])!='true':
        run(['docker','start',ACTIVE])
    final=wait_ready(ACTIVE,8000,900)
    (RESULTS/'restoration.json').write_text(json.dumps({'health':final,'containers':inventory()},indent=2))
    print('RESTORED EXL3; original MLX container remains stopped intact',flush=True)
def interrupt(signum,frame):raise KeyboardInterrupt(f'signal {signum}')
signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGINT,interrupt)
before=inventory();assert before[ACTIVE]['Running'] and not before[ORIGINAL]['Running']
(RESULTS/'before.json').write_text(json.dumps({'containers':before,'test_image_id':capture(['docker','image','inspect','--format','{{.Id}}',IMAGE])},indent=2))
private=ROOT/'private';private.mkdir(mode=0o700,exist_ok=True)
for name in (ACTIVE,ORIGINAL):
    p=private/(name+'-inspect.json');p.write_text(capture(['docker','inspect',name]));p.chmod(0o600)
try:
    run(['docker','stop','-t','60',ACTIVE])
    for keep in (32,48,64):
        print('START KEEP',keep,flush=True)
        args=['docker','run','-d','--name',TEST,'--restart','no','--init','--gpus','all','--ipc','host',
              '--ulimit','memlock=-1','--ulimit','stack=67108864','-p','127.0.0.1:18000:8000',
              '-v',str(ROOT)+':/experiment:ro',
              '-v','ieti-qwen38-flash-next-tensorfold-mlx-4bit-mtp-int8-ssd-vision-128gb-hf-cache:/root/.cache/huggingface',
              '-v','ieti-qwen38-flash-next-tensorfold-mlx-4bit-mtp-int8-ssd-vision-128gb-runtime-cache:/root/.cache/tensorfold',
              '-v','ieti-qwen38-flash-next-tensorfold-mlx-4bit-mtp-int8-ssd-vision-128gb-kernel-cache:/root/.cache/tensorfold-kernels',
              '-e',f'SNAPSHOT_TEST_KEEP={keep}','-e','PYTHONUNBUFFERED=1','-e','TENSORFOLD_NO_UPDATE_CHECK=1',
              '-e','TENSORFOLD_NO_LIVE=1',IMAGE,'/opt/tensorfold-venv/bin/python','/experiment/tools/start_server.py']
        (RESULTS/f'keep{keep}-docker-command.json').write_text(json.dumps(args,indent=2))
        run(args)
        try:
            ready=wait_ready(TEST,18000,1200)
            assert ready['context_length']==75000 and ready['streams']['max']==16
            (RESULTS/f'keep{keep}-health-ready.json').write_text(json.dumps(ready,indent=2))
            pid=capture(['docker','inspect','--format','{{.State.Pid}}',TEST])
            # Docker init is PID 1; its API child is recorded by the low-overhead monitor.
            children=Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
            api_pid=children[0] if children else pid
            run([sys.executable,str(ROOT/'tools/campaign.py'),'--keep',str(keep),'--outdir',str(RESULTS),
                 '--manifest',str(ROOT/'prompts.json'),'--pid',api_pid],timeout=1500)
            (RESULTS/f'keep{keep}-state-end.json').write_text(capture(['docker','inspect','--format','{{json .State}}',TEST]))
        finally:
            (RESULTS/f'keep{keep}-startup.log').write_text(capture(['docker','logs',TEST]))
            subprocess.run(['docker','stop','-t','60',TEST],stdout=subprocess.DEVNULL)
            subprocess.run(['docker','rm',TEST],stdout=subprocess.DEVNULL)
    (RESULTS/'completed.json').write_text(json.dumps({'variants':[32,48,64],'completed':True}))
finally:
    restore()
