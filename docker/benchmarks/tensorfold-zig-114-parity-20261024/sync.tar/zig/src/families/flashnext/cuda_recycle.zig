//! Flash Next per-stream device buffers kept for the next stream instead of going back to the driver: a stream's
//! caches, its head's and the prompt cache's states take ~120 driver allocations and ~17 ms to make each time.
//! Sizes round up to eighths of their power of two so different caps share buffers; TF_FLASHNEXT_RECYCLE_MIB caps
//! the bytes kept (default 2048; 0: off), and an allocation the driver refuses frees every kept buffer and retries.
//! Callers free only once the stream has drained the buffer's work, as before.
const std = @import("std");
const cuda = @import("cuda");

const slots = 2048;

var kept: [slots]cuda.DeviceBuffer = undefined;
var kept_n: usize = 0;
var kept_bytes: usize = 0;
var limit: ?usize = null;
var busy: std.atomic.Value(bool) = .init(false);
var live_bytes: std.atomic.Value(usize) = .init(0); // driver memory behind every buffer made here, kept ones too

fn lock() void {
    while (busy.cmpxchgWeak(false, true, .acquire, .monotonic) != null) std.atomic.spinLoopHint();
}

fn unlock() void {
    busy.store(false, .release);
}

fn cap() usize {
    if (limit) |l| return l;
    const mib: usize = if (std.c.getenv("TF_FLASHNEXT_RECYCLE_MIB")) |v| std.fmt.parseInt(usize, std.mem.span(v), 10) catch 2048 else 2048;
    limit = mib << 20;
    return limit.?;
}

/// `len` rounded up to the next eighth of its power of two (at most 12.5% more).
fn rounded(len: usize) usize {
    if (len <= 4096) return 4096;
    const step = @as(usize, 1) << @intCast(std.math.log2_int(usize, len) - 3);
    return std.mem.alignForward(usize, len, step);
}

/// Driver bytes behind the buffers made here: the streams' caches, their heads' and the prompt cache's states.
pub fn live() u64 {
    return live_bytes.load(.monotonic);
}

fn made(d: *const cuda.Driver, len: usize) !cuda.DeviceBuffer {
    const b = try cuda.DeviceBuffer.alloc(d, len);
    _ = live_bytes.fetchAdd(b.len, .monotonic);
    return b;
}

fn freed(b: *cuda.DeviceBuffer) void {
    _ = live_bytes.fetchSub(b.len, .monotonic);
    b.free();
}

/// A buffer of at least `len` bytes (a kept one of its size class when there is one), contents undefined.
pub fn alloc(d: *const cuda.Driver, len: usize) !cuda.DeviceBuffer {
    if (len == 0 or cap() == 0) return made(d, len);
    const size = rounded(len);
    lock();
    for (kept[0..kept_n], 0..) |b, i| if (b.len == size and b.d == d) {
        kept[i] = kept[kept_n - 1];
        kept_n -= 1;
        kept_bytes -= size;
        unlock();
        return b;
    };
    unlock();
    return made(d, size) catch |err| {
        if (flush() == 0) return err;
        return made(d, size);
    };
}

/// Keep `b` for a later `alloc` while there is room, else return it to the driver.
pub fn free(b: *cuda.DeviceBuffer) void {
    if (b.ptr == 0 or b.borrowed) return b.free();
    if (b.len != rounded(b.len) or cap() == 0) return freed(b);
    lock();
    if (kept_n < slots and kept_bytes + b.len <= cap()) {
        kept[kept_n] = b.*;
        kept_n += 1;
        kept_bytes += b.len;
        unlock();
        b.* = undefined;
        return;
    }
    unlock();
    freed(b);
}

/// Every kept buffer back to the driver; how many there were.
pub fn flush() usize {
    lock();
    defer unlock();
    const n = kept_n;
    for (kept[0..kept_n]) |*b| freed(b);
    kept_n = 0;
    kept_bytes = 0;
    return n;
}

test "sizes round up to eighths of their power of two" {
    try std.testing.expectEqual(@as(usize, 4096), rounded(1));
    try std.testing.expectEqual(@as(usize, 1 << 20), rounded(1 << 20));
    try std.testing.expectEqual(@as(usize, (1 << 20) + (1 << 17)), rounded((1 << 20) + 1));
}
