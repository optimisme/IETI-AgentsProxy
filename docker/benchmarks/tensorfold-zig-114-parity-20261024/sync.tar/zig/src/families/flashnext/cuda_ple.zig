//! Layer 2's n-gram table: the hash of each token's row ids, and the mapped table a pass gathers its rows from.

const std = @import("std");
const cuda = @import("cuda");
const core = @import("core");
const embed = @import("cuda_embed.zig");
const hc = @import("cuda_hc.zig");
const ple_pool = @import("cuda_ple_pool.zig");
const ple_prefetch = @import("cuda_ple_prefetch.zig");

const golden: u64 = 0x9E3779B97F4A7C15;
const mix1: u64 = 0xBF58476D1CE4E5B9;
const mix2: u64 = 0x94D049BB133111EB;
const prime_step: u64 = 10007;
pub const max_n: usize = 8;
pub const max_heads: usize = 64;
const max_shards: usize = 128;
pub const layer: usize = 1;

const Tensor = core.safetensors.Tensor;

pub const Hash = struct {
    n: usize,
    per: usize,
    heads: usize,
    eos: i64,
    dh: usize,
    shards: usize,
    sizes: [max_heads]i64 = undefined,
    offsets: [max_heads]i64 = undefined,
    mult: [max_n]i64 = undefined,
    starts: [max_shards + 1]i64 = undefined,

    pub fn init(args: struct {
        vocab: u64,
        ngram: usize,
        per: usize,
        base: u64,
        divisor: u64,
        shards: usize,
        seed: u64,
        eos: i64,
        ple_dim: usize,
        ple_index: usize,
    }) !Hash {
        if (args.ngram < 2 or args.ngram > max_n or args.per == 0 or args.shards == 0 or args.shards > max_shards) return error.UnexpectedTensor;
        if (args.base < 2 or args.divisor == 0) return error.UnexpectedTensor;
        const heads = (args.ngram - 1) * args.per;
        if (heads > max_heads or args.ple_dim == 0 or args.ple_dim % heads != 0) return error.UnexpectedTensor;
        var h = Hash{ .n = args.ngram, .per = args.per, .heads = heads, .eos = args.eos, .dh = args.ple_dim / heads, .shards = args.shards };
        var total: i64 = 0;
        for (0..heads) |head| {
            const size: i64 = @intCast(nthPrimeAfter(args.base - 1, args.ple_index * heads + head + 1));
            h.sizes[head] = size;
            h.offsets[head] = total;
            total += size;
        }
        const divisor: i64 = @intCast(args.divisor);
        const shard_n: i64 = @intCast(args.shards);
        const padded = divCeil(total, divisor) * divisor;
        const base: i64 = @divFloor(padded, shard_n);
        const extra: usize = @intCast(@mod(padded, shard_n));
        var acc: i64 = 0;
        for (0..args.shards) |i| {
            h.starts[i] = acc;
            acc += base + @as(i64, @intFromBool(i < extra));
        }
        h.starts[args.shards] = acc;
        const half: u64 = @max(1, (((1 << 63) - 1) / @max(args.vocab, 1)) / 2);
        const seed = args.seed +% prime_step *% @as(u64, @intCast(args.ple_index));
        for (0..args.ngram) |i| {
            const mixed = splitmix64(seed +% golden *% @as(u64, @intCast(i + 1)));
            h.mult[i] = @intCast(2 * (mixed % half) + 1);
        }
        return h;
    }

    pub fn locate(h: Hash, row: i64) !struct { shard: usize, local: usize } {
        if (row < 0 or row >= h.starts[h.shards]) return error.UnexpectedTensor;
        var lo: usize = 0;
        var hi = h.shards;
        while (lo + 1 < hi) {
            const mid = (lo + hi) / 2;
            if (h.starts[mid] <= row) lo = mid else hi = mid;
        }
        return .{ .shard = lo, .local = @intCast(row - h.starts[lo]) };
    }
};

fn splitmix64(value: u64) u64 {
    var v = value +% golden;
    v = (v ^ (v >> 30)) *% mix1;
    v = (v ^ (v >> 27)) *% mix2;
    return v ^ (v >> 31);
}

fn isPrime(value: u64) bool {
    if (value < 2) return false;
    if (value % 2 == 0) return value == 2;
    var d: u64 = 3;
    while (d <= value / d) : (d += 2) if (value % d == 0) return false;
    return true;
}

fn nthPrimeAfter(start: u64, count: usize) u64 {
    var prime = start;
    for (0..count) |_| {
        prime += 1;
        while (!isPrime(prime)) prime += 1;
    }
    return prime;
}

fn divCeil(a: i64, b: i64) i64 {
    return @divFloor(a + b - 1, b);
}

/// Row ids of one new token after `history` (n - 1 ids). A fresh decode window is n - 1 copies of eos.
pub fn lastIds(h: Hash, history: []const i64, token: i64, out: []i64) !void {
    if (history.len != h.n - 1 or out.len != h.heads) return error.UnexpectedTensor;
    var seq: [max_n]i64 = undefined;
    for (history, 0..) |v, i| seq[i] = v;
    seq[history.len] = token;
    const width = h.n;
    var eos_at: [max_n]i64 = undefined;
    for (0..width) |i| eos_at[i] = if (seq[i] == h.eos) @intCast(i) else -1;
    var acc: [max_n]i64 = undefined;
    acc[0] = eos_at[0];
    for (1..width) |i| acc[i] = @max(acc[i - 1], eos_at[i]);
    var before: [max_n]i64 = undefined;
    before[0] = -1;
    for (1..width) |i| before[i] = acc[i - 1];
    var shifted: [max_n]i64 = undefined;
    const pos: i64 = @intCast(width - 1);
    const in_segment = pos - (before[width - 1] + 1);
    for (0..h.n) |shift| {
        const source = pos - @as(i64, @intCast(shift));
        const taken = seq[@intCast(@max(source, 0))];
        const keep = in_segment >= @as(i64, @intCast(shift)) and source >= 0;
        shifted[shift] = if (keep) taken else h.eos;
    }
    var at: usize = 0;
    var ngram: usize = 2;
    while (ngram <= h.n) : (ngram += 1) {
        var mixed = shifted[0] *% h.mult[0];
        for (1..ngram) |p| mixed = mixed ^ (shifted[p] *% h.mult[p]);
        for (0..h.per) |_| {
            out[at] = @mod(mixed, h.sizes[at]) + h.offsets[at];
            at += 1;
        }
    }
}

pub fn toBf16(v: f32) u16 {
    const bits: u32 = @bitCast(v);
    if (std.math.isNan(v)) return @intCast((bits >> 16) | 0x40);
    return @intCast((bits + 0x7FFF + ((bits >> 16) & 1)) >> 16);
}

pub fn sumGroups(row: []const u16, out: []f32) void {
    const groups = row.len / 32;
    for (0..groups) |g| {
        var buf: [32]f32 = undefined;
        for (0..32) |i| buf[i] = @bitCast(@as(u32, row[g * 32 + i]) << 16);
        var n: usize = 32;
        while (n > 1) {
            n /= 2;
            for (0..n) |i| buf[i] = buf[2 * i] + buf[2 * i + 1];
        }
        out[g] = buf[0];
    }
}

/// One mapped shard (core.safetensors.File) with a typed lookup.
pub const Open = struct {
    file: core.safetensors.File,
    io: std.Io,

    pub fn load(gpa: std.mem.Allocator, io: std.Io, path: []const u8) !Open {
        return .{ .file = try core.safetensors.File.open(gpa, io, path), .io = io };
    }

    pub fn close(self: *Open, gpa: std.mem.Allocator) void {
        _ = gpa;
        self.file.close(self.io);
    }

    pub fn tensor(self: *const Open, name: []const u8, dtype: core.safetensors.DType) !Tensor {
        const t = self.file.get(name) orelse return error.MissingTensor;
        if (t.dtype != dtype) return error.UnexpectedTensor;
        return t;
    }
};

pub fn readI64(t: Tensor, out: []i64) !void {
    if (t.dtype != .i64 or t.rank != 1 or t.dim(0) != out.len or t.bytes.len != out.len * 8) return error.UnexpectedTensor;
    for (out, 0..) |*o, i| o.* = std.mem.readInt(i64, t.bytes[8 * i ..][0..8], .little);
}

pub fn weightName(buf: []u8, shard: usize, nested: bool) ![]const u8 {
    return if (nested)
        std.fmt.bufPrint(buf, "language_model.model.layers.{d}.ple.ple_embedding.ngram_embedding.shards.{d}.weight", .{ layer, shard })
    else
        std.fmt.bufPrint(buf, "language_model.model.layers.{d}.ple.ple_embedding.ngram_embedding.shard_{d}.weight", .{ layer, shard });
}

pub fn partName(buf: []u8, shard: usize, nested: bool, part: []const u8) ![]const u8 {
    return partNameFor(buf, shard, nested, part, false);
}

fn partNameFor(buf: []u8, shard: usize, nested: bool, part: []const u8, modelopt: bool) ![]const u8 {
    const prefix = if (modelopt) "model.language_model" else "language_model.model";
    return if (nested)
        std.fmt.bufPrint(buf, "{s}.layers.{d}.ple.ple_embedding.ngram_embedding.shards.{d}.{s}", .{ prefix, layer, shard, part })
    else
        std.fmt.bufPrint(buf, "{s}.layers.{d}.ple.ple_embedding.ngram_embedding.shard_{d}.{s}", .{ prefix, layer, shard, part });
}

pub fn findOpen(opened: []Open, path: []const u8) ?*Open {
    for (opened) |*o| if (std.mem.eql(u8, o.file.path, path)) return o;
    return null;
}

pub fn copyRow(file: *const Open, shard: usize, nested: bool, local: usize, dh: usize, words: []u8, scales: []u8, biases: []u8) !void {
    var name: [180]u8 = undefined;
    const w = try file.tensor(try partName(&name, shard, nested, "weight"), .u32);
    const s = try file.tensor(try partName(&name, shard, nested, "scales"), .bf16);
    const b = try file.tensor(try partName(&name, shard, nested, "biases"), .bf16);
    const words_w = dh / 8;
    const groups = dh / 32;
    if (w.dim(1) != words_w or s.dim(1) != groups or b.dim(1) != groups or local >= w.dim(0)) return error.UnexpectedTensor;
    const wb = words_w * 4;
    const gb = groups * 2;
    @memcpy(words, w.bytes[local * wb ..][0..wb]);
    @memcpy(scales, s.bytes[local * gb ..][0..gb]);
    @memcpy(biases, b.bytes[local * gb ..][0..gb]);
}

pub fn tableScale(gpa: std.mem.Allocator, io: std.Io, dir: []const u8, wm: std.json.ObjectMap) !f32 {
    return readScale(gpa, io, dir, wm, "language_model.model.layers.1.ple.ple_embedding.ngram_embedding.weight_scale", false);
}

fn readScale(gpa: std.mem.Allocator, io: std.Io, dir: []const u8, wm: std.json.ObjectMap, name: []const u8, required: bool) !f32 {
    const file = wm.get(name) orelse return if (required) error.MissingTensor else 1;
    const path = try std.fs.path.join(gpa, &.{ dir, file.string });
    defer gpa.free(path);
    var opened = try Open.load(gpa, io, path);
    defer opened.close(gpa);
    const t = opened.file.get(name) orelse return error.MissingTensor;
    if (t.numel() != 1) return error.UnexpectedTensor;
    return switch (t.dtype) {
        .f32 => @bitCast(std.mem.readInt(u32, t.bytes[0..4], .little)),
        .f64 => @floatCast(@as(f64, @bitCast(std.mem.readInt(u64, t.bytes[0..8], .little)))),
        .bf16 => @bitCast(@as(u32, std.mem.readInt(u16, t.bytes[0..2], .little)) << 16),
        else => error.UnexpectedTensor,
    };
}

fn jsonU64(v: std.json.Value) !u64 {
    if (v != .integer or v.integer < 0) return error.UnexpectedTensor;
    return @intCast(v.integer);
}

fn optU64(o: std.json.ObjectMap, name: []const u8, default: u64) !u64 {
    const v = o.get(name) orelse return default;
    if (v == .null) return default;
    return jsonU64(v);
}

const NgramSpec = struct {
    vocab: u64,
    ngram: usize,
    per: usize,
    base: u64,
    divisor: u64,
    shards: usize,
    seed: u64,
    eos: i64,
    ple_dim: usize,
    ple_index: usize,
};

/// `ple_layer_ids` value 2 is decoder layer 1. The eos id is the text config's, which the hash mixes in.
pub fn readSpec(gpa: std.mem.Allocator, io: std.Io, dir: []const u8) !NgramSpec {
    const path = try std.fs.path.join(gpa, &.{ dir, "config.json" });
    defer gpa.free(path);
    const bytes = try std.Io.Dir.cwd().readFileAlloc(io, path, gpa, .limited(1 << 24));
    defer gpa.free(bytes);
    const parsed = try std.json.parseFromSlice(std.json.Value, gpa, bytes, .{});
    defer parsed.deinit();
    const root = parsed.value.object;
    const text = if (root.get("text_config")) |v| if (v == .object and v.object.count() > 0) v.object else root else root;
    const layers = try jsonU64(text.get("num_hidden_layers") orelse return error.MissingTensor);
    if (layers <= layer) return error.UnexpectedTensor;
    const hidden = try jsonU64(text.get("hidden_size") orelse return error.MissingTensor);
    const ids = text.get("ple_layer_ids") orelse return error.MissingTensor;
    if (ids != .array) return error.UnexpectedTensor;
    var seen: [512]bool = @splat(false);
    var ple_index: usize = 0;
    var found = false;
    for (ids.array.items) |item| {
        const id = try jsonU64(item);
        if (id == 0 or id > layers or id > seen.len) return error.UnexpectedTensor;
        if (id == layer + 1) found = true;
        if (!seen[id - 1] and id - 1 < layer) ple_index += 1;
        seen[id - 1] = true;
    }
    if (!found) return error.UnexpectedTensor;
    const eos: i64 = if (text.get("eos_token_id")) |v| blk: {
        if (v == .null) break :blk 0;
        if (v == .array) {
            if (v.array.items.len == 0) return error.UnexpectedTensor;
            break :blk @intCast(try jsonU64(v.array.items[0]));
        }
        break :blk @intCast(try jsonU64(v));
    } else 0;
    return .{
        .vocab = try jsonU64(text.get("vocab_size") orelse return error.MissingTensor),
        .ngram = @intCast(try optU64(text, "ngram_size", 3)),
        .per = @intCast(try optU64(text, "heads_per_ngram", 8)),
        .base = try optU64(text, "ngram_vocab_size_base", 20_000_000),
        .divisor = try optU64(text, "make_ngram_vocab_size_divisible_by", 128),
        .shards = @intCast(try optU64(text, "split_ngram_parts", 128)),
        .seed = try optU64(text, "seed", 1234),
        .eos = eos,
        .ple_dim = @intCast(try optU64(text, "ple_embed_dim", hidden)),
        .ple_index = ple_index,
    };
}

/// The text config's eos id, which a fresh n-gram window repeats.
pub fn eosOf(gpa: std.mem.Allocator, io: std.Io, model_dir: []const u8) !i64 {
    const cfg = try readSpec(gpa, io, model_dir);
    return cfg.eos;
}

/// How mlx rows are read: through the mapping (upstream), by pread from the page cache, by O_DIRECT pread
/// straight from the drive (no page cache: no reclaim stalls under memory pressure, no cache the tables crowd),
/// or hybrid: through the mapping when the row's pages are cached, else O_DIRECT (a cache miss never faults).
const Read = enum { map, pread, direct, hybrid };

/// TF_FLASHNEXT_PLE_PREAD: 1 pread, direct O_DIRECT pread, hybrid; unset or 0 the mapping.
fn readMode() Read {
    const v = std.mem.span(std.c.getenv("TF_FLASHNEXT_PLE_PREAD") orelse return .map);
    if (std.mem.eql(u8, v, "1")) return .pread;
    if (std.mem.eql(u8, v, "direct")) return .direct;
    if (std.mem.eql(u8, v, "hybrid")) return .hybrid;
    return .map;
}

/// Whether every page under `bytes` is in the page cache (mincore), so reading it through the mapping cannot
/// wait on the drive; false on any refusal, which sends the row to the O_DIRECT read.
fn resident(bytes: []const u8) bool {
    const page = 4096;
    const lo = @intFromPtr(bytes.ptr) & ~@as(usize, page - 1);
    const hi = std.mem.alignForward(usize, @intFromPtr(bytes.ptr) + bytes.len, page);
    var vec: [4]u8 = undefined;
    const pages = (hi - lo) / page;
    if (pages > vec.len) return false;
    if (std.os.linux.errno(std.os.linux.mincore(@ptrFromInt(lo), hi - lo, &vec)) != .SUCCESS) return false;
    for (vec[0..pages]) |v| if (v & 1 == 0) return false;
    return true;
}

/// `dst.len` bytes at `offset` through an O_DIRECT descriptor: the aligned blocks that hold them, then the slice.
fn readDirect(fd: std.c.fd_t, dst: []u8, offset: u64) !void {
    var block: [8192]u8 align(4096) = undefined;
    const start = offset & ~@as(u64, 4095);
    const end = std.mem.alignForward(u64, offset + dst.len, 4096);
    if (end - start > block.len) return error.UnexpectedTensor;
    const rc = std.c.pread(fd, &block, end - start, @intCast(start));
    // the file's last block reads short: enough when it covers the wanted bytes
    if (rc < 0 or @as(u64, @intCast(rc)) < offset + dst.len - start) return error.ReadFailed;
    @memcpy(dst, block[offset - start ..][0..dst.len]);
}

fn readAt(fd: std.c.fd_t, buf: []u8, offset: u64) !void {
    var done: usize = 0;
    while (done < buf.len) {
        const rc = std.c.pread(fd, buf[done..].ptr, buf.len - done, @intCast(offset + done));
        if (rc <= 0) return error.ReadFailed;
        done += @intCast(rc);
    }
}

/// The n-gram table held open for an engine's life: the hash, the scale, and each shard's slices of its mapped file.
pub const Ngram = struct {
    gpa: std.mem.Allocator,
    hash: Hash,
    scale: f32,
    files: std.ArrayList(Open) = .empty,
    w: [max_shards][]const u8 = undefined,
    s: [max_shards][]const u8 = undefined,
    b: [max_shards][]const u8 = undefined,
    format: enum { mlx, nvfp4 } = .mlx,
    tables: [max_shards]core.nvfp4_rows.Table = undefined,
    pool: ?*ple_pool.Pool = null, // the gather's parked workers (null: every row on the caller's thread)
    /// Each mlx shard's file and its weight/scales/biases file offsets: rows read with pread, not mapping faults.
    fd: [max_shards]std.c.fd_t = undefined,
    w_off: [max_shards]u64 = undefined,
    s_off: [max_shards]u64 = undefined,
    b_off: [max_shards]u64 = undefined,
    read: Read = .map,
    direct_fds: std.ArrayList(std.c.fd_t) = .empty, // O_DIRECT descriptors, one a file (read == .direct)
    bfd: [max_shards]std.c.fd_t = undefined, // each shard's buffered descriptor (the mapping's), for readahead
    prefetcher: ?*ple_prefetch.Prefetch = null, // rows asked into the page cache while the head drafts (hybrid)

    pub fn init(gpa: std.mem.Allocator, io: std.Io, model_dir: []const u8) !Ngram {
        const cfg = try readSpec(gpa, io, model_dir);
        var g: Ngram = .{ .gpa = gpa, .hash = try Hash.init(.{
            .vocab = cfg.vocab,
            .ngram = cfg.ngram,
            .per = cfg.per,
            .base = cfg.base,
            .divisor = cfg.divisor,
            .shards = cfg.shards,
            .seed = cfg.seed,
            .eos = cfg.eos,
            .ple_dim = cfg.ple_dim,
            .ple_index = cfg.ple_index,
        }), .scale = 1 };
        errdefer g.deinit();
        const index_path = try std.fs.path.join(gpa, &.{ model_dir, "model.safetensors.index.json" });
        defer gpa.free(index_path);
        const text = try std.Io.Dir.cwd().readFileAlloc(io, index_path, gpa, .limited(1 << 26));
        defer gpa.free(text);
        const parsed = try std.json.parseFromSlice(std.json.Value, gpa, text, .{});
        defer parsed.deinit();
        const wm = try core.safetensors.index.weightMap(parsed.value);
        const first = "model.language_model.layers.1.ple.ple_embedding.ngram_embedding.shard_0.weight";
        const modelopt = wm.contains(first);
        g.format = if (modelopt) .nvfp4 else .mlx;
        g.scale = if (modelopt)
            try readScale(gpa, io, model_dir, wm, "model.language_model.layers.1.ple.ple_embedding.ngram_embedding.weight_scale_2", true)
        else
            try tableScale(gpa, io, model_dir, wm);
        const dh = g.hash.dh;
        g.read = if (g.format == .mlx) readMode() else .map;
        var key: [180]u8 = undefined;
        var file_fd: std.c.fd_t = -1;
        for (0..g.hash.shards) |shard| {
            var nested = false;
            const mapped = if (wm.get(try partNameFor(&key, shard, false, "weight", modelopt))) |v|
                v.string
            else blk: {
                nested = true;
                break :blk (wm.get(try partNameFor(&key, shard, true, "weight", modelopt)) orelse return error.MissingTensor).string;
            };
            const path = try std.fs.path.join(gpa, &.{ model_dir, mapped });
            defer gpa.free(path);
            const file = findOpen(g.files.items, path) orelse file: {
                var o = try Open.load(gpa, io, path);
                errdefer o.close(gpa);
                if (@import("builtin").os.tag != .windows) std.posix.madvise(o.file.map.memory.ptr, o.file.map.memory.len, std.posix.MADV.RANDOM) catch {};
                if (g.read == .direct or g.read == .hybrid) {
                    const z = try gpa.dupeSentinel(u8, path, 0);
                    defer gpa.free(z);
                    const fd = std.c.open(z, .{ .ACCMODE = .RDONLY, .DIRECT = true });
                    if (fd < 0) return error.FileNotFound;
                    g.direct_fds.append(gpa, fd) catch |err| {
                        _ = std.c.close(fd);
                        return err;
                    };
                }
                try g.files.append(gpa, o);
                break :file &g.files.items[g.files.items.len - 1];
            };
            const w = try file.tensor(try partNameFor(&key, shard, nested, "weight", modelopt), if (modelopt) .u8 else .u32);
            const expected_rows: usize = @intCast(g.hash.starts[shard + 1] - g.hash.starts[shard]);
            if (w.rank != 2 or w.dim(0) != expected_rows) return error.UnexpectedTensor;
            if (modelopt) {
                const sc = try file.tensor(try partNameFor(&key, shard, nested, "weight_scale", true), .f8_e4m3);
                const table = try core.nvfp4_rows.Table.init(w, sc, g.scale);
                if (table.width != dh) return error.UnexpectedTensor;
                g.tables[shard] = table;
            } else {
                const sc = try file.tensor(try partNameFor(&key, shard, nested, "scales", false), .bf16);
                const bias = try file.tensor(try partNameFor(&key, shard, nested, "biases", false), .bf16);
                if (!w.is(.u32, &.{ expected_rows, dh / 8 }) or !sc.is(.bf16, &.{ expected_rows, dh / 32 }) or
                    !bias.is(.bf16, &.{ expected_rows, dh / 32 })) return error.UnexpectedTensor;
                g.w[shard] = w.bytes;
                g.s[shard] = sc.bytes;
                g.b[shard] = bias.bytes;
                const base = @intFromPtr(file.file.map.memory.ptr);
                if (g.read == .direct or g.read == .hybrid) {
                    // the descriptor opened beside this shard's file (files and descriptors are appended together)
                    const at = (@intFromPtr(file) - @intFromPtr(g.files.items.ptr)) / @sizeOf(Open);
                    file_fd = g.direct_fds.items[at];
                }
                g.fd[shard] = if (g.read == .direct or g.read == .hybrid) file_fd else file.file.file.handle;
                g.bfd[shard] = file.file.file.handle;
                g.w_off[shard] = @intFromPtr(w.bytes.ptr) - base;
                g.s_off[shard] = @intFromPtr(sc.bytes.ptr) - base;
                g.b_off[shard] = @intFromPtr(bias.bytes.ptr) - base;
            }
        }
        g.pool = try ple_pool.Pool.create(gpa, io);
        if (g.read == .hybrid) g.prefetcher = try ple_prefetch.Prefetch.create(gpa, io);
        return g;
    }

    pub fn deinit(g: *Ngram) void {
        if (g.prefetcher) |p| p.destroy(g.gpa);
        if (g.pool) |p| p.destroy();
        for (g.files.items) |*o| o.close(g.gpa);
        g.files.deinit(g.gpa);
        for (g.direct_fds.items) |fd| _ = std.c.close(fd);
        g.direct_fds.deinit(g.gpa);
    }

    /// Values a row's embedding holds (heads x head width).
    pub fn width(g: *const Ngram) usize {
        return g.hash.heads * g.hash.dh;
    }

    /// Rows [lo, hi) of a chunk's token-major row ids `ids`, each dequantized into its head's slice of `out`.
    pub fn fill(g: *const Ngram, ids: []const i64, out: []u16, lo: usize, hi: usize) !void {
        const dh = g.hash.dh;
        for (lo..hi) |i| {
            const loc = try g.hash.locate(ids[i]);
            const row = out[i * dh ..][0..dh];
            if (g.read == .hybrid and g.cached(loc.shard, loc.local)) {
                try embed.dequant(g.w[loc.shard], g.s[loc.shard], g.b[loc.shard], dh, loc.local, row);
                continue;
            }
            if (g.read != .map) {
                try g.readRow(loc.shard, loc.local, row);
                continue;
            }
            switch (g.format) {
                .mlx => try embed.dequant(g.w[loc.shard], g.s[loc.shard], g.b[loc.shard], dh, loc.local, row),
                .nvfp4 => try g.tables[loc.shard].gather(&.{loc.local}, row),
            }
        }
    }

    /// Ask the rows of `tokens` after `history` (two tokens, advanced past them) into the page cache, without
    /// waiting: the next verify's rows while the head still drafts. Nothing without a prefetcher.
    pub fn prefetch(g: *const Ngram, history: []i64, tokens: []const u32) void {
        const p = g.prefetcher orelse return;
        const heads = g.hash.heads;
        if (history.len != g.hash.n - 1 or heads > 64) return;
        const wb = g.hash.dh / 8 * 4;
        const gb = g.hash.dh / 32 * 2;
        var ids: [64]i64 = undefined;
        for (tokens) |token| {
            lastIds(g.hash, history, @intCast(token), ids[0..heads]) catch return;
            for (0..history.len - 1) |i| history[i] = history[i + 1];
            history[history.len - 1] = token;
            for (ids[0..heads]) |id| {
                const loc = g.hash.locate(id) catch continue;
                const fd = g.bfd[loc.shard];
                p.push(.{ .fd = fd, .offset = g.w_off[loc.shard] + loc.local * wb, .len = @intCast(wb) });
                p.push(.{ .fd = fd, .offset = g.s_off[loc.shard] + loc.local * gb, .len = @intCast(gb) });
                p.push(.{ .fd = fd, .offset = g.b_off[loc.shard] + loc.local * gb, .len = @intCast(gb) });
            }
        }
        p.kick();
    }

    /// Whether a row's words, scales and biases all sit in the page cache.
    fn cached(g: *const Ngram, shard: usize, local: usize) bool {
        const wb = g.hash.dh / 8 * 4;
        const gb = g.hash.dh / 32 * 2;
        return resident(g.w[shard][local * wb ..][0..wb]) and resident(g.s[shard][local * gb ..][0..gb]) and
            resident(g.b[shard][local * gb ..][0..gb]);
    }

    /// One mlx row by pread from the page cache (no mapping faults), dequantized as `embed.dequant` does.
    fn readRow(g: *const Ngram, shard: usize, local: usize, row: []u16) !void {
        const dh = g.hash.dh;
        if (dh > 256 or dh % 32 != 0) return error.UnexpectedTensor;
        const wb = dh / 8 * 4;
        const gb = dh / 32 * 2;
        var words: [128]u8 = undefined;
        var scales: [16]u8 = undefined;
        var biases: [16]u8 = undefined;
        const read = if (g.read == .pread) &readAt else &readDirect;
        try read(g.fd[shard], words[0..wb], g.w_off[shard] + local * wb);
        try read(g.fd[shard], scales[0..gb], g.s_off[shard] + local * gb);
        try read(g.fd[shard], biases[0..gb], g.b_off[shard] + local * gb);
        try embed.dequant(words[0..wb], scales[0..gb], biases[0..gb], dh, 0, row);
    }

    /// One call's rows split into `parts` equal ranges, part i filling [i * per, (i + 1) * per).
    const Split = struct {
        g: *const Ngram,
        ids: []const i64,
        out: []u16,
        per: usize,

        fn part(ctx: *const anyopaque, i: usize) anyerror!void {
            const s: *const Split = @ptrCast(@alignCast(ctx));
            const lo = @min(s.ids.len, i * s.per);
            try s.g.fill(s.ids, s.out, lo, @min(s.ids.len, lo + s.per));
        }
    };

    /// `embedding` for each token after `history` (moved past the chunk) into out and xs, read by up to 128 threads.
    pub fn rows(g: *const Ngram, history: []i64, tokens: []const u32, out: []u16, xs: []f32) !void {
        const heads = g.hash.heads;
        const w = g.width();
        if (history.len != g.hash.n - 1 or out.len != tokens.len * w or xs.len != out.len / 32) return error.UnexpectedTensor;
        const items = tokens.len * heads;
        const ids = try g.gpa.alloc(i64, items);
        defer g.gpa.free(ids);
        var hist: [max_n]i64 = undefined;
        @memcpy(hist[0..history.len], history);
        for (tokens, 0..) |token, t| {
            try lastIds(g.hash, hist[0..history.len], @intCast(token), ids[t * heads ..][0..heads]);
            for (0..history.len - 1) |i| hist[i] = hist[i + 1];
            hist[history.len - 1] = token;
        }
        const n_threads = ple_pool.partsFor(items);
        if (n_threads <= 1 or g.pool == null) {
            try g.fill(ids, out, 0, items);
        } else {
            const split: Split = .{ .g = g, .ids = ids, .out = out, .per = (items + n_threads - 1) / n_threads };
            try g.pool.?.run(n_threads, .{ .ctx = &split, .run = Split.part });
        }
        for (0..tokens.len) |t| {
            const row = out[t * w ..][0..w];
            if (g.format == .mlx and g.scale != 1) {
                for (row) |*v| {
                    const f: f32 = @bitCast(@as(u32, v.*) << 16);
                    v.* = toBf16(f * g.scale);
                }
            }
            sumGroups(row, xs[t * (w / 32) ..][0 .. w / 32]);
        }
        @memcpy(history, hist[0..history.len]);
    }
    pub const Window = @import("cuda_ple_windows.zig").Window;

    /// Independent histories share one gather; the original single-window path remains the control.
    pub fn rowsMany(g: *const Ngram, windows: []const Window, out: []u16, xs: []f32) !void {
        return @import("cuda_ple_windows.zig").rows(g, windows, out, xs);
    }
};

test "a fresh window hashes token 7 into sixteen rows" {
    const h = try Hash.init(.{
        .vocab = 248320,
        .ngram = 3,
        .per = 8,
        .base = 20_000_000,
        .divisor = 128,
        .shards = 128,
        .seed = 1234,
        .eos = 248044,
        .ple_dim = 2560,
        .ple_index = 0,
    });
    try std.testing.expectEqual(@as(i64, 23703573157769), h.mult[0]);
    const history = [_]i64{ 248044, 248044 };
    var ids: [16]i64 = undefined;
    try lastIds(h, &history, 7, &ids);
    const want = [_]i64{ 2927653, 34980843, 54748278, 66612378, 97814964, 109013870, 126560393, 151352333, 167888935, 182235580, 215170017, 237467519, 247510681, 278779700, 296141806, 304994522 };
    try std.testing.expectEqualSlices(i64, &want, &ids);
    const loc = try h.locate(ids[0]);
    try std.testing.expectEqual(@as(usize, 1), loc.shard);
    try std.testing.expectEqual(@as(usize, 427641), loc.local);
}

test {
    _ = @import("cuda_ple_nvfp4_test.zig");
    _ = @import("cuda_ple_pool.zig");
    _ = @import("cuda_ple_pool_gather_test.zig");
}
