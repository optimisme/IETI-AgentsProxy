//! TF_FLASHNEXT_PROFILE=3: a prompt pass's synchronized time per kernel step, summed by name over the chunk
//! (diagnostics only: every lap waits for the stream).
const std = @import("std");
const cuda = @import("cuda");

var state: enum { unknown, off, on } = .unknown;
var names: [48][]const u8 = undefined;
var spent: [48]u64 = undefined;
var calls: [48]u32 = undefined;
var used: usize = 0;
var mark: u64 = 0;

pub fn on() bool {
    if (state == .unknown) {
        const v = std.c.getenv("TF_FLASHNEXT_PROFILE");
        state = if (v != null and std.mem.eql(u8, std.mem.span(v.?), "3")) .on else .off;
    }
    return state == .on;
}

fn nowUs() u64 {
    const c = @import("sys").c;
    var t: c.timespec = undefined;
    _ = c.clock_gettime(c.CLOCK.MONOTONIC, &t);
    return @as(u64, @intCast(t.sec)) * 1_000_000 + @as(u64, @intCast(t.nsec)) / 1000;
}

/// Start a chunk's laps.
pub fn begin(stream: cuda.Stream) void {
    if (!on()) return;
    stream.synchronize() catch {};
    used = 0;
    mark = nowUs();
}

/// The time since the last lap, waited for, to `name`.
pub fn lap(stream: cuda.Stream, name: []const u8) void {
    if (!on()) return;
    stream.synchronize() catch {};
    const now = nowUs();
    const i = for (names[0..used], 0..) |n, j| {
        if (n.ptr == name.ptr) break j;
    } else blk: {
        if (used == names.len) return;
        names[used] = name;
        spent[used] = 0;
        calls[used] = 0;
        used += 1;
        break :blk used - 1;
    };
    spent[i] += now - mark;
    calls[i] += 1;
    mark = nowUs();
}

pub fn report(rows: usize) void {
    if (!on()) return;
    var total: u64 = 0;
    for (spent[0..used]) |t| total += t;
    std.debug.print("kernels: {d} rows, {d:.1} ms:", .{ rows, @as(f64, @floatFromInt(total)) / 1e3 });
    for (names[0..used], spent[0..used], calls[0..used]) |n, t, c| std.debug.print(" {s}={d:.1}/{d}", .{ n, @as(f64, @floatFromInt(t)) / 1e3, c });
    std.debug.print("\n", .{});
}
