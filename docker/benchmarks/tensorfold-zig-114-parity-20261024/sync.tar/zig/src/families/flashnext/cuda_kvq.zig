//! --kv-cache fp8 on Flash Next: the Python engine's --kv-dtype int8 rows (flashnext_kv8.cuh), set once at open.
const wt = @import("cuda_prompt_wt.zig");

/// Whether the attention caches hold int8 rows; set before any sequence or kernel is made.
pub var on: bool = false;

/// One position's keys (or values) in a layer's cache: bf16 heads, or int8 codes then an fp16 scale per 32.
pub fn rowBytes() usize {
    return if (on) wt.kv_heads * wt.head_dim + wt.kv_heads * (wt.head_dim / 32) * 2 else wt.kv_heads * wt.head_dim * 2;
}

test "an int8 row is 544 bytes of the bf16 row's 1024 at two heads of 256" {
    const std = @import("std");
    try std.testing.expectEqual(@as(usize, 2 * 256 * 2), rowBytes());
    on = true;
    defer on = false;
    try std.testing.expectEqual(@as(usize, 2 * 256 + 2 * 8 * 2), rowBytes());
}
