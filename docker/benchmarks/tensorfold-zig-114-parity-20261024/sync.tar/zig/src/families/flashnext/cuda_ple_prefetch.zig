//! N-gram rows the next verify will gather, asked into the page cache while the head still drafts: the verify's
//! hybrid read then finds them cached instead of waiting on the drive (Python's stage-ahead, on the draft's time).
//! A hint only: a full ring drops reads, and a row not yet in when the verify comes is read there as before.
const std = @import("std");
const linux = std.os.linux;

/// One readahead: `len` bytes of `fd` at `offset`.
pub const Item = struct { fd: std.c.fd_t, offset: u64, len: u32 };

const cap = 8192;
const max_workers = 16;

pub const Prefetch = struct {
    io: std.Io,
    ring: [cap]Item = undefined,
    head: std.atomic.Value(u32) = .init(0), // the next slot the producer writes
    tail: std.atomic.Value(u32) = .init(0), // the next slot a worker claims
    stopping: std.atomic.Value(bool) = .init(false),
    threads: [max_workers]std.Thread = undefined,
    spawned: usize = 0,

    /// TF_FLASHNEXT_PLE_PREFETCH workers (default 8; 0: no prefetch, null).
    pub fn create(gpa: std.mem.Allocator, io: std.Io) !?*Prefetch {
        const n = if (std.c.getenv("TF_FLASHNEXT_PLE_PREFETCH")) |v| std.fmt.parseInt(usize, std.mem.span(v), 10) catch 8 else 8;
        if (n == 0) return null;
        const p = try gpa.create(Prefetch);
        p.* = .{ .io = io };
        errdefer p.destroy(gpa);
        while (p.spawned < @min(n, max_workers)) : (p.spawned += 1) p.threads[p.spawned] = try std.Thread.spawn(.{}, work, .{p});
        return p;
    }

    pub fn destroy(p: *Prefetch, gpa: std.mem.Allocator) void {
        p.stopping.store(true, .release);
        _ = p.head.fetchAdd(0, .release);
        p.io.futexWake(u32, &p.head.raw, max_workers);
        for (p.threads[0..p.spawned]) |th| th.join();
        gpa.destroy(p);
    }

    /// Queue a readahead (single producer: the lane host's thread); dropped when the ring is full.
    pub fn push(p: *Prefetch, it: Item) void {
        const h = p.head.load(.monotonic);
        if (h -% p.tail.load(.acquire) >= cap) return;
        p.ring[h % cap] = it;
        p.head.store(h +% 1, .release);
    }

    /// Wake the workers for what `push` queued.
    pub fn kick(p: *Prefetch) void {
        p.io.futexWake(u32, &p.head.raw, @intCast(p.spawned));
    }

    fn work(p: *Prefetch) void {
        while (true) {
            const t = p.tail.load(.acquire);
            const h = p.head.load(.acquire);
            if (t == h) {
                if (p.stopping.load(.acquire)) return;
                p.io.futexWaitUncancelable(u32, &p.head.raw, h);
                continue;
            }
            if (p.tail.cmpxchgWeak(t, t +% 1, .acq_rel, .acquire) != null) continue;
            const it = p.ring[t % cap];
            _ = linux.fadvise(it.fd, @intCast(it.offset), it.len, linux.POSIX_FADV.WILLNEED);
        }
    }
};
