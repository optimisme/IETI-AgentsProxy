//! The next prompt chunk's n-gram rows, gathered on a host thread while this chunk runs (Python's stage-ahead for
//! prompt pieces): a chunk's own gather overlaps only the embedding and layer 0, so a long prompt otherwise waits
//! on the drive at layer 1 of every chunk. TF_FLASHNEXT_PLE_AHEAD=0 turns it off.
const std = @import("std");
const ple = @import("cuda_ple.zig");
const Gather = @import("cuda_batch_state.zig").Gather;

pub fn enabled() bool {
    const v = std.c.getenv("TF_FLASHNEXT_PLE_AHEAD") orelse return true;
    return !std.mem.eql(u8, std.mem.span(v), "0");
}

pub const Ahead = struct {
    gpa: std.mem.Allocator,
    thread: ?std.Thread = null,
    gather: Gather = undefined,
    /// The rows asked, the history they follow, and that history advanced past them by the gather.
    ids: std.ArrayList(u32) = .empty,
    from: [2]i64 = undefined,
    hist: [2]i64 = undefined,
    emb: []u16 = &.{},
    xs: []f32 = &.{},

    pub fn create(gpa: std.mem.Allocator) !*Ahead {
        const a = try gpa.create(Ahead);
        a.* = .{ .gpa = gpa };
        return a;
    }

    pub fn destroy(a: *Ahead) void {
        a.join();
        a.ids.deinit(a.gpa);
        a.gpa.free(a.emb);
        a.gpa.free(a.xs);
        a.gpa.destroy(a);
    }

    fn join(a: *Ahead) void {
        if (a.thread) |th| th.join();
        a.thread = null;
    }

    /// Start gathering `ids` after `from` (`width` values a row); a gather still running is waited for first.
    pub fn start(a: *Ahead, ngram: *const ple.Ngram, io: std.Io, from: [2]i64, ids: []const u32, width: usize) !void {
        a.join();
        a.ids.clearRetainingCapacity();
        try a.ids.appendSlice(a.gpa, ids);
        if (a.emb.len < ids.len * width) {
            a.gpa.free(a.emb);
            a.emb = &.{};
            a.gpa.free(a.xs);
            a.xs = &.{};
            a.emb = try a.gpa.alloc(u16, ids.len * width);
            a.xs = try a.gpa.alloc(f32, ids.len * width / 32);
        }
        a.from = from;
        a.hist = from;
        a.gather = .{ .ngram = ngram, .history = a.hist[0..], .ids = a.ids.items, .emb = a.emb[0 .. ids.len * width], .xs = a.xs[0 .. ids.len * width / 32], .io = io };
        a.thread = try std.Thread.spawn(.{}, Gather.main, .{&a.gather});
    }

    /// The rows of `ids` after `history` into emb and xs, history advanced past them, when the last start asked
    /// exactly those; false (nothing written) otherwise, the gather left for its own chunk: another stream's
    /// pass (a lone decode verify) may come between a prompt's chunks.
    pub fn take(a: *Ahead, ngram: *const ple.Ngram, history: *[2]i64, ids: []const u32, emb: []u16, xs: []f32) bool {
        if (a.thread == null or a.gather.ngram != ngram) return false;
        if (!std.mem.eql(i64, &a.from, history) or !std.mem.eql(u32, a.ids.items, ids)) return false;
        a.join();
        if (a.gather.failed != null) return false;
        @memcpy(emb, a.gather.emb);
        @memcpy(xs, a.gather.xs);
        history.* = a.hist;
        return true;
    }
};

/// The two-token history after `ids` follow `history`.
pub fn after(history: [2]i64, ids: []const u32) [2]i64 {
    if (ids.len >= 2) return .{ ids[ids.len - 2], ids[ids.len - 1] };
    if (ids.len == 1) return .{ history[1], ids[0] };
    return history;
}

test "the history after a chunk keeps its last two tokens" {
    try std.testing.expectEqual([2]i64{ 5, 6 }, after(.{ 1, 2 }, &.{ 4, 5, 6 }));
    try std.testing.expectEqual([2]i64{ 2, 9 }, after(.{ 1, 2 }, &.{9}));
    try std.testing.expectEqual([2]i64{ 1, 2 }, after(.{ 1, 2 }, &.{}));
}
