//! TF_HOST_TRACE=1: the lane host's admission, fill and round events on stderr with monotonic ms (diagnostics only).
const std = @import("std");
const c = @import("sys").c;

var on: ?bool = null;

pub fn enabled() bool {
    if (on) |v| return v;
    const v = if (std.c.getenv("TF_HOST_TRACE")) |x| std.mem.eql(u8, std.mem.span(x), "1") else false;
    on = v;
    return v;
}

pub fn note(comptime fmt: []const u8, args: anytype) void {
    if (!enabled()) return;
    var t: c.timespec = undefined;
    _ = c.clock_gettime(c.CLOCK.MONOTONIC, &t);
    const ms = @as(u64, @intCast(t.sec)) * 1000 + @as(u64, @intCast(t.nsec)) / 1_000_000;
    std.debug.print("host {d}: " ++ fmt ++ "\n", .{ms} ++ args);
}
