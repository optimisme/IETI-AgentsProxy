// Ours: --kv-cache fp8 for Flash Next as the Python engine's --kv-dtype int8 keeps it (kvcache.py, kvquant.py):
// ExLlamaV3's cache quantization, groups of 32 values H32-rotated, int8 codes q - 128 on the midpoint grid and an
// fp16 absmax scale a group. Queries ride the rotation (q . Hk = Hq . k); values stay rotated and the merged output
// takes one H32 back (p . Hv = H (p . v)). A cache row is a position's NKV heads of HD codes, then their NKV * HD / 32
// fp16 scales: one contiguous row a position, as the bf16 cache's, so copies and snapshots move whole rows.
#pragma once
#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <stdint.h>

namespace fn_kv8 {

constexpr float C32 = 0.17677669529663688110f;  // 1 / sqrt(32): H32 H32 = I

// Bytes of one position's row: NKV heads of HD codes, then their fp16 scales.
__host__ __device__ constexpr int row_bytes(int nkv, int hd) { return nkv * hd + nkv * (hd / 32) * 2; }

// One butterfly stage over lane bit `m`: the lower lane keeps a + b, the upper a - b (kvquant._h32_stage).
__device__ __forceinline__ float stage(float x, int m) {
    const float o = __shfl_xor_sync(0xffffffffu, x, m);
    return (threadIdx.x & m) ? __fsub_rn(o, x) : __fadd_rn(x, o);
}

// H32 over a warp's 32 values (one a lane), bit 0 first as kvquant.h32 runs it, then 1 / sqrt(32).
__device__ __forceinline__ float h32(float x) {
    x = stage(x, 1);
    x = stage(x, 2);
    x = stage(x, 4);
    x = stage(x, 8);
    x = stage(x, 16);
    return __fmul_rn(x, C32);
}

// quant_groups_8 for the warp's group: the code at `code`, the lane-0 fp16 scale at `scale`.
__device__ __forceinline__ void quant(float x, signed char* code, __half* scale) {
    const float rot = h32(x);
    float amax = fabsf(rot);
#pragma unroll
    for (int o = 16; o > 0; o /= 2) amax = fmaxf(amax, __shfl_xor_sync(0xffffffffu, amax, o));
    const float s = __fadd_rn(amax, 1e-10f);
    const float inv = __fdiv_rn(1.0f, s);
    const float q = __fadd_rn(floorf(__fmul_rn(__fmul_rn(rot, inv), 128.0f)), 128.0f);
    *code = static_cast<signed char>(static_cast<int>(fminf(fmaxf(q, 0.0f), 255.0f)) - 128);
    if ((threadIdx.x & 31) == 0) *scale = __float2half_rn(s);
}

// dequant_group_8 of 8 codes at `codes` under `scale`: (code + 0.5) * s / 128, rounded to bf16, packed as a uint4.
__device__ __forceinline__ uint4 dequant8(const unsigned char* codes, float scale) {
    const uint2 raw = *reinterpret_cast<const uint2*>(codes);
    const signed char* c = reinterpret_cast<const signed char*>(&raw);
    uint4 out;
    __nv_bfloat16* o = reinterpret_cast<__nv_bfloat16*>(&out);
#pragma unroll
    for (int i = 0; i < 8; ++i) o[i] = __float2bfloat16_rn(__fmul_rn(__fmul_rn(__fadd_rn(static_cast<float>(c[i]), 0.5f), scale), 0.0078125f));
    return out;
}

}  // namespace fn_kv8
