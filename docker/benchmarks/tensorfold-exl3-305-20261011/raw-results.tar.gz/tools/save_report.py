import hashlib
import json
import shutil
import tarfile
from pathlib import Path

ROOT = Path('/tmp/tensorfold-exl3-305-20261011')
REPO = Path('/Users/albertpalaciosjimenez/Documents/GitHub/IETI-AgentsProxy')
DEST = REPO/'docker/benchmarks/tensorfold-exl3-305-20261011'
DEST.mkdir(parents=True, exist_ok=True)
data = json.loads((ROOT/'results/comparison.json').read_text())
deployment = json.loads((ROOT/'results/final-deployment.json').read_text())
data['final_deployment'] = deployment
data['rollback'] = {
    'endpoint': 'ssh super@localhost -p 2226',
    'commands_remote': [
        'docker stop -t 60 qwen38_flash_next_cuda_vram128_tensorfold_exl3_305_mtp_int8_ssd_vision',
        'docker start qwen38_flash_next_cuda_vram128_tensorfold_mlx_4bit_mtp_int8_ssd_vision',
    ],
    'preserved_backup_remote': '~/tensorfold-exl3-305-20261011/baseline/',
    'preserved_image_tag': 'ieti/tensorfold-before-exl3:20261011',
    'original_container_left_stopped': True,
    'original_recipe_unchanged': True,
    'restart_note': 'Docker start resumes the retained original container; Compose recreation instead reruns its bootstrap.',
}
for name, remote_sha in deployment['recipes_sha256'].items():
    local_sha = hashlib.sha256((REPO/'docker/models'/name).read_bytes()).hexdigest()
    assert local_sha == remote_sha, (name, local_sha, remote_sha)
assert deployment['installed_source_matches_original']
assert deployment['active']['state']['Running']
assert deployment['active']['restart_count'] == 0
assert deployment['health']['ok']
assert deployment['original']['state']['Status'] == 'exited'
data['tools_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'tools').glob('*.py')}
cap = next(x for x in data['runs'] if x['run'] == 'contextmix65k-exl3')
data['additional_context_test'] = {
    'description': 'EXL3 only: 8 short requests, 7 approximately 7400-token prompts, 1 approximately 65000-token prompt; every request generates 512 tokens.',
    'matched_mlx_control': False, 'successes': cap['successes'],
    'longest_request': max(cap['per_request'], key=lambda r:r['input_tokens']),
    'aggregate_tok_s': cap['tok_s'],
    'does_not_validate': '16 simultaneously full 75000-token contexts or long-context programming accuracy.',
}
data['vision_smoke_test'] = {'via': 'OpenCode on localhost:8006', 'expected': '3 red rectangles', 'response': '3 red rectangles.', 'passed': True}
data['memory_estimates_not_benchmarks'] = {
    'kv_bytes_per_token_int8_with_mtp': 18304,
    'kv_gib_16_times_75000': 16*75000*18304/2**30,
    'kv_gib_12_times_75000': 12*75000*18304/2**30,
    'kv_gib_saved_four_full_contexts': 4*75000*18304/2**30,
    'caveats': 'KV grows with actual tokens; stream metadata, retained state, scratch buffers, model, table, vision and OS require additional memory. These are KV-only estimates, not measured startup savings.',
    'mlx_3bit_checkpoint_exists': 'TensorFold/Qwen3.8-Flash-Next-MLX-3bit-MTP',
    'current_flash_next_cuda_mlx_formats': {'bits':4, 'group_size':32},
    'mlx_3bit_drop_in_supported': False,
    'mlx_mapped_partial_pinning_experiment_performed': False,
}
data['interpretation'] = {
    'performance': 'No measurable decode throughput gain; prefill-heavy and mixed throughput decrease, with higher TTFT.',
    'recommendation_for_opencode_speed': 'Preserved MLX 4-bit / KV int8 deployment.',
    'current_deployment': 'Requested EXL3 3.05 / KV int8 candidate remains running and healthy; original MLX container is stopped intact.',
    'quality': 'Both variants pass 23 tests on 3 small OpenCode coding tasks; EXL3 passes one vision smoke test. This does not establish broad model quality equivalence.',
}
data['limitations'] += [
    'One approximately 66k input in a mixed cohort is a capacity smoke test, without a matched MLX control.',
    'OpenCode baseline task timings overlapped the checkpoint download; coding tests are used for correctness, not comparative latency.',
    'Health requests_running can include queued work; max_running in the monitor is not the number of concurrently executing GPU streams.',
    'Linux MemAvailable alone does not establish unified-memory headroom for simultaneous maximum contexts.',
]
data['sources'] = [
    'https://github.com/ashhart/TensorFold/blob/v0.6.5/docs/recipes/qwen3.8-flash-next.md',
    'https://github.com/ashhart/TensorFold/blob/v0.6.5/src/tensorfold/families/qwen4_exp/__init__.py',
    'https://huggingface.co/TensorFold/Qwen3.8-Flash-Next-MLX-3bit-MTP',
]
text = json.dumps(data, indent=2, allow_nan=False)+'\n'
(ROOT/'results/comparison.json').write_text(text)
(DEST/'results.json').write_text(text)
# Archive only experiment results and temporary coding fixtures, excluding
# credentials, container environment dumps, OpenCode state databases and caches.
archive = ROOT/'raw-results.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for dirname in ['results','fixtures','heldout']:
        t.add(ROOT/dirname, arcname=dirname)
    for name in ['bench_long_context.py','bench_context_mix.py','opencode_cases.py','analyze.py','save_report.py','verify_deployment.py','campaign.sh','exl3_campaign.sh','prepare_vision.py']:
        t.add(ROOT/'tools'/name, arcname='tools/'+name)
print('Saved', DEST/'results.json')
print('Raw archive', archive, archive.stat().st_size, 'bytes')
print('Archive SHA256', hashlib.sha256(archive.read_bytes()).hexdigest())
