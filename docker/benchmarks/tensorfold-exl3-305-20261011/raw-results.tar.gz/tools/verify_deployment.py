import hashlib
import json
import subprocess
import urllib.request
from pathlib import Path

ROOT = Path.home() / 'tensorfold-exl3-305-20261011'
ACTIVE = 'qwen38_flash_next_cuda_vram128_tensorfold_exl3_305_mtp_int8_ssd_vision'
ORIGINAL = 'qwen38_flash_next_cuda_vram128_tensorfold_mlx_4bit_mtp_int8_ssd_vision'

def command(args):
    return subprocess.check_output(args, text=True).strip()

def api(path):
    with urllib.request.urlopen('http://127.0.0.1:8000' + path, timeout=20) as response:
        return json.load(response)

def container_state(name):
    fmt = '{{json .State}}|{{.RestartCount}}|{{.Image}}|{{.Id}}'
    state, restarts, image, container = command(['docker', 'inspect', '--format', fmt, name]).split('|')
    return dict(state=json.loads(state), restart_count=int(restarts), image=image, container_id=container)

source = '''import hashlib, importlib.metadata, json, pathlib, tensorfold, torch
root = pathlib.Path(tensorfold.__file__).parent
files = ['families/qwen4_exp/cuda/engine.py', 'families/qwen4_exp/cuda/forward.py', 'families/qwen4_exp/cuda/exl3.py', 'families/qwen4_exp/cuda/exl3_pack.py', 'families/qwen4_exp/cuda/exl3_mm.py']
print(json.dumps({'version': importlib.metadata.version('tensorfold'), 'sources': {f: hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}, 'torch': torch.__version__, 'cuda': torch.version.cuda, 'gpu_visible': torch.cuda.is_available(), 'gpu': torch.cuda.get_device_name(0)}, indent=2))'''
runtime = json.loads(command(['docker', 'exec', ACTIVE, '/opt/tensorfold-venv/bin/python', '-c', source]))
baseline = json.loads((ROOT/'baseline/sources.json').read_text())
files = ['qwen38-flash-next-tensorfold-vontra-mlx-4bit-mtp-int8-ssd-vision-128gb.yml', 'qwen38-flash-next-tensorfold-exl3-305-mtp-int8-ssd-vision-128gb.yml']
out = {
    'active': container_state(ACTIVE), 'original': container_state(ORIGINAL),
    'health': api('/health'), 'models': api('/v1/models'),
    'runtime': runtime, 'installed_source_matches_original': runtime['sources'] == baseline['sources'],
    'source_commit': command(['docker', 'exec', ACTIVE, 'git', '-C', '/opt/tensorfold-source', 'rev-parse', 'HEAD']),
    'recipes_sha256': {f: hashlib.sha256((Path.home()/'docker/models'/f).read_bytes()).hexdigest() for f in files},
    'baseline_recipe_sha256': hashlib.sha256((ROOT/'baseline/recipe.yml').read_bytes()).hexdigest(),
    'backup_image': command(['docker', 'image', 'inspect', '--format', '{{.Id}}', 'ieti/tensorfold-before-exl3:20261011']),
    'host_memory': {line.split(':')[0]: line.split(':')[1].strip() for line in Path('/proc/meminfo').read_text().splitlines() if line.split(':')[0] in ('MemTotal','MemAvailable','SwapTotal','SwapFree')},
}
(ROOT/'results/final-deployment.json').write_text(json.dumps(out, indent=2))
(ROOT/'results/exl3-pip-freeze.txt').write_text(command(['docker', 'exec', ACTIVE, '/opt/tensorfold-venv/bin/pip', 'freeze'])+'\n')
print(json.dumps({k:out[k] for k in ('installed_source_matches_original','source_commit','recipes_sha256','baseline_recipe_sha256','runtime','host_memory')}, indent=2))
print('active', out['active']['state']['Status'], 'restart_count', out['active']['restart_count'])
print('original', out['original']['state']['Status'])
print('health', json.dumps(out['health']))
