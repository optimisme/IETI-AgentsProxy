"""Read-only extra capacity cohort: 8 short + 7 ~7.4k + one ~65k, 16 requests.
Reuses original client HTTP/timing/monitoring without changing matched A/B trials.
"""
import bench_long_context as bench
original=bench.freeze_prompts

def freeze(args):
 specs=original(args)
 if args.workload!='mixed' or args.n!=16: raise ValueError('requires --workload mixed --n 16')
 item=specs[-1]
 text=bench.prompt_for('prefill',item['normalized_prompt_seed']+':65k',args.trial,item['index'],291200)
 item['prompt']=text;item['body']['messages'][0]['content']=text
 item['prompt_tokens_target']=65000;item['prompt_chars']=len(text)
 item['prompt_sha256']=bench.sha(text);item['request_body_sha256']=bench.sha(item['body'])
 return specs

bench.freeze_prompts=freeze
if __name__=='__main__':raise SystemExit(bench.main())
