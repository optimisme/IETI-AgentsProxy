#!/bin/bash
set -euo pipefail
root="$HOME/tensorfold-exl3-305-20261011"
container=qwen38_flash_next_cuda_vram128_tensorfold_exl3_305_mtp_int8_ssd_vision
for ((i=0;i<240;i++)); do
 if curl -sf --max-time 2 http://127.0.0.1:8000/health > "$root/results/exl3-startup-health.json"; then break; fi
 sleep 5
done
curl -sf http://127.0.0.1:8000/health > "$root/results/exl3-startup-health.json"
pid=$(docker top "$container" -eo pid,comm | awk '$2=="tensorfold" {print $1}')
python3 "$root/tools/bench_long_context.py" --base-url http://127.0.0.1:8000 --n 16 --trial 0 --run-tag warmup-exl3 --prompt-seed exl3-warmup --variant exl3-warmup --pair-set exl3-305 --outdir "$root/results/warmup" --max-tokens 64 --workload decode --omit-top-k --omit-generation-seed --pid "$pid" --no-gpu-monitor --save-prompts
python3 "$root/tools/bench_long_context.py" --base-url http://127.0.0.1:8000 --n 16 --trial 1 --run-tag exl3-decode-1 --prompt-seed kv-int4-20261011 --variant exl3 --pair-set exl3-305 --outdir "$root/results" --max-tokens 512 --workload decode --omit-top-k --omit-generation-seed --pid "$pid" --no-gpu-monitor --save-prompts
bash "$root/tools/campaign.sh" exl3 "$container"
