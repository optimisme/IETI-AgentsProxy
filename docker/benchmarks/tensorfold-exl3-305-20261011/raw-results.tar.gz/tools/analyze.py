import json,statistics,hashlib
import bench_long_context as bench
from pathlib import Path
ROOT=Path('/tmp/tensorfold-exl3-305-20261011')
r=ROOT/'results'; reports=[]
for p in sorted(r.glob('*-summary.json')):
 if p.name.startswith('opencode'): continue
 s=json.loads(p.read_text());b=s['health_before'];a=s['health_after'];monitor=p.with_name(p.name.replace('-summary.json','-monitor.jsonl'))
 ms=[json.loads(x) for x in monitor.read_text().splitlines()] if monitor.exists() else []
 rows={'run':p.stem.replace('-summary',''),'requests':s['requests'],'successes':s['successes'],'full_output_requests':s['full_output_budget_requests'],'wall_s':s['wall_s'],'tok_s':s['aggregate_output_tokens_per_s'],'input_tokens':s['input_tokens'],'ttft_s':s['ttft_output_s'],'ttft_content_s':s['ttft_content_s'],'latency_s':s['latency_s'],'tpot_ms_approx':s['tpot_ms_approx'],'all_cache_zero':s['all_cache_counts_zero'],'errors':s['request_errors'],'per_request':s['per_request'],'cohorts':{k:{'ttft_s':v['ttft_output_s'],'latency_s':v['latency_s']} for k,v in s.get('cohorts',{}).items()},'health_delta':{k:a[k]-b[k] for k in b.keys() & a.keys() if k.endswith('_total') and isinstance(b[k],(int,float))},'external_requests_estimate':a['requests_total']-b['requests_total']-s['requests'],'max_running':max([x['health'].get('requests_running',0) for x in ms]+[0]),'min_host_mem_available_gib':min([x['host_memory']['MemAvailable_kb']/1024**2 for x in ms if 'host_memory' in x]+[float('inf')]),'max_swap_used_gib':max([(x['host_memory']['SwapTotal_kb']-x['host_memory']['SwapFree_kb'])/1024**2 for x in ms if 'host_memory' in x]+[0])}
 reports.append(rows)
comp={}
for workload in ['decode','prefill','mixed']:
 left=[x for x in reports if x['run'].startswith('mlx-'+workload)]
 right=[x for x in reports if x['run'].startswith('exl3-'+workload)]
 if left and right:
  pooled=lambda xs:sum(x['full_output_requests']*512 for x in xs)/sum(x['wall_s'] for x in xs)
  comp[workload]={'mlx_tok_s_pooled':pooled(left),'exl3_tok_s_pooled':pooled(right),'change_pct':100*(pooled(right)/pooled(left)-1),'mlx_range':[min(x['tok_s'] for x in left),max(x['tok_s'] for x in left)],'exl3_range':[min(x['tok_s'] for x in right),max(x['tok_s'] for x in right)]}
  matches=[]
  for l in left:
   rp=r/(l['run'].replace('mlx-','exl3-',1)+'-settings.json');lp=r/(l['run']+'-settings.json')
   if rp.exists():
    ls=json.loads(lp.read_text());rs=json.loads(rp.read_text());matches.append({'trial':ls['trial'],'prompt_hashes_match':[x['prompt_sha256'] for x in ls['prompt_manifest']]==[x['prompt_sha256'] for x in rs['prompt_manifest']]})
  comp[workload]['matched_prompts']=matches
  for label,xs in [('mlx',left),('exl3',right)]:
   comp[workload][label+'_ttft_s_pooled']=bench.describe([v['ttft_output_s'] for x in xs for v in x['per_request']])
   comp[workload][label+'_latency_s_pooled']=bench.describe([v['latency_s'] for x in xs for v in x['per_request']])
opencode={}
for p in r.glob('opencode-*-summary.json'):opencode[p.stem]=json.loads(p.read_text())
for name, cases in opencode.items():
 for c in cases:
  events=r/f'opencode-{c["variant"]}-{c["case"]}.jsonl'
  c['tool_outcomes']=[]
  for line in events.read_text().splitlines():
   e=json.loads(line)
   if e.get('type')=='tool_use':
    pt=e['part']; st=pt.get('state',{}); c['tool_outcomes'].append({'tool':pt.get('tool'),'status':st.get('status'),'error':st.get('error')})
out={'date':'2026-10-11','engine':'TensorFold Python 0.6.5','commit':'609ca419abecebdc5a059498a613680bd3aa847f','baseline_model':'TensorFold/Qwen3.8-Flash-Next-MLX-4bit-MTP','candidate_model':'turboderp/Qwen3.8-Flash-Next-exl3','candidate_revision':'69e33439ae950f17bcbe95c98f117d80f759ab6d','candidate_branch':'3.05bpw_h5_ng5','settings':{'parallel':16,'context':75000,'kv_dtype':'int8','vision':True,'mtp_drafts':6,'mtp_confidence':.6,'thinking_budget':1024,'snapshots':32,'ssd_batch_patch_installed':True,'exl3_branch_batched':False,'baseline_ple_on_ssd':True,'exl3_ple_on_ssd':False,'exl3_ngram_storage':'own file-mapped EXL3 table; upstream default prefetch/locking enabled; MLX-only SSD flag is rejected','exl3_vision':'official converter v3, F16 sidecar dequantized from this exact EXL3 pack','exl3_vision_sha256':'cbacd744a92f11da677b7c7168db4bcf7d7b1856241f738db236881dc44fcd30'},'runs':reports,'comparison':comp,'opencode':opencode,'limitations':['Aggregate tok/s is 8192 tokens divided by cohort wall time, including prefill. Generated reasoning counts toward output tokens.','Three decode trials; prefill and mixed initially one trial each.','Temperature 0.1 without supported generation seed; quantization changes outputs and MTP acceptance.','Small background requests detected by health deltas are recorded per trial; no claim of perfectly isolated load.','No GPU timeline, no GIL or SSD syscall profiling.','OpenCode direct tunnel testing in isolated temporary Python fixtures, not the student proxy. Hidden tests were withheld and outside the agent working directory.','Small coding test sample cannot establish general quality equivalence or 75k coding accuracy.','This is a practical deployment comparison, not an isolated bit-width test: EXL3 uses different kernels, weights, n-gram encoding and file-mapped staging.']}
(r/'comparison.json').write_text(json.dumps(out,indent=2)); print(json.dumps(comp,indent=2)); print('runs',len(reports))
