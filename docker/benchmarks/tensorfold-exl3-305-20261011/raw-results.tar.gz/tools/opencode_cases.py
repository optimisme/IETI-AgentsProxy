import json, os, shutil, subprocess, time, hashlib
from pathlib import Path
ROOT=Path('/tmp/tensorfold-exl3-305-20261011')
CASES={
'normalize':{
'prompt':'Fix normalize.py: strip whitespace, use Unicode casefold, discard empty names, remove duplicates preserving first appearance, accept any iterable including generators, and do not mutate inputs. Inspect the files, edit only normalize.py, run the public unittest suite, then summarize.',
'file':'normalize.py','initial':'def normalize_names(values):\n    return sorted(set(values))\n',
'public':'''import unittest
from normalize import normalize_names
class Tests(unittest.TestCase):
 def test_basic(self): self.assertEqual(normalize_names([' Bob ', 'ALICE', 'bob', '', '  ']), ['bob', 'alice'])
 def test_no_mutation(self):
  values=[' Bob ','Bob']; before=values.copy(); normalize_names(values); self.assertEqual(values,before)
''',
'heldout':'''import unittest
from normalize import normalize_names
class Hidden(unittest.TestCase):
 def test_unicode(self): self.assertEqual(normalize_names(['Straße','STRASSE',' École ','ÉCOLE']),['strasse','école'])
 def test_generator(self): self.assertEqual(normalize_names(x for x in [' B ','a','b',' c ']),['b','a','c'])
 def test_empty(self): self.assertEqual(normalize_names(iter([])),[])
 def test_order(self): self.assertEqual(normalize_names(['Z','A','z','C','a']),['z','a','c'])
'''},
'deps':{
'prompt':'Implement order_tasks(deps) in deps.py. deps maps each task name to an iterable of prerequisite task names. Return a topological ordering, always taking the lexicographically smallest currently ready task. Duplicate prerequisites count once. Raise ValueError on a missing prerequisite or any cycle (including self dependency). Empty input returns []. Do not mutate input. Inspect files, edit only deps.py, run public unittests and summarize.',
'file':'deps.py','initial':'def order_tasks(deps):\n    return sorted(deps)\n',
'public':'''import unittest
from deps import order_tasks
class Tests(unittest.TestCase):
 def test_chain(self): self.assertEqual(order_tasks({'a':['z'],'z':[]}),['z','a'])
 def test_tie(self): self.assertEqual(order_tasks({'c':['a'],'b':[],'a':[]}),['a','b','c'])
 def test_cycle(self):
  with self.assertRaises(ValueError): order_tasks({'a':['b'],'b':['a']})
''',
'heldout':'''import unittest
from deps import order_tasks
class Hidden(unittest.TestCase):
 def test_new_ready_precedes(self): self.assertEqual(order_tasks({'z':[],'b':['a'],'a':[]}),['a','b','z'])
 def test_dupes(self): self.assertEqual(order_tasks({'b':['a','a'],'a':[]}),['a','b'])
 def test_missing(self):
  with self.assertRaises(ValueError): order_tasks({'a':['absent']})
 def test_self_cycle(self):
  with self.assertRaises(ValueError): order_tasks({'a':['a']})
 def test_empty(self): self.assertEqual(order_tasks({}),[])
 def test_mutation(self):
  d={'b':['a'],'a':[]}; order_tasks(d); self.assertEqual(d,{'b':['a'],'a':[]})
'''},
'money':{
'prompt':'Implement totals(csv_text) in money.py using standard-library csv and Decimal. Input CSV has headers account,amount. Trim account names; reject blank account or invalid/non-finite Decimal amount with ValueError. Sum exact amounts per account BEFORE rounding each final total to two decimal places with ROUND_HALF_UP. Return a dict of account to Decimal, retaining insertion order. Support quoted account names containing commas, CRLF and empty CSV with only headers. Do not use float. Inspect files, edit only money.py, run public unittests and summarize.',
'file':'money.py','initial':'def totals(csv_text):\n    return {}\n',
'public':'''import unittest
from decimal import Decimal
from money import totals
class Tests(unittest.TestCase):
 def test_basic(self): self.assertEqual(totals('account,amount\\na,0.1\\na,0.2\\nb,2.345\\n'),{'a':Decimal('0.30'),'b':Decimal('2.35')})
 def test_empty(self): self.assertEqual(totals('account,amount\\n'),{})
''',
'heldout':'''import unittest
from decimal import Decimal
from money import totals
class Hidden(unittest.TestCase):
 def test_sum_before_round(self): self.assertEqual(totals('account,amount\\nx,0.004\\nx,0.004\\n'),{'x':Decimal('0.01')})
 def test_negative_half(self): self.assertEqual(totals('account,amount\\nx,-1.005\\n'),{'x':Decimal('-1.01')})
 def test_quoted(self): self.assertEqual(totals('account,amount\\r\\n" Team, A ",1.20\\r\\n'),{'Team, A':Decimal('1.20')})
 def test_nonfinite(self):
  for amount in ['NaN','Infinity','-Infinity','nope']:
   with self.subTest(amount=amount),self.assertRaises(ValueError): totals('account,amount\\nx,'+amount+'\\n')
 def test_blank(self):
  with self.assertRaises(ValueError): totals('account,amount\\n ,2\\n')
 def test_type_order(self):
  r=totals('account,amount\\nz,1\\na,2\\n'); self.assertEqual(list(r),['z','a']); self.assertTrue(all(isinstance(x,Decimal) for x in r.values()))
'''}}

def run(variant,model):
 configroot=ROOT/(variant+'-config')/'opencode'; configroot.mkdir(parents=True,exist_ok=True)
 base=json.loads(Path('/tmp/tensorfold-kv-int4-20261011/opencode-config/opencode/opencode.json').read_text())
 old=next(iter(base['provider']['spark']['models'])); mdl=base['provider']['spark']['models'].pop(old)
 base['provider']['spark']['models'][model]=mdl
 base['model']=base['small_model']='spark/'+model
 base['agent']['kvprobe']['prompt']='Work only in the current temporary fixture directory. Inspect the source and public tests with read/glob/grep, edit only the source file named by the user, run python3 -m unittest -v. Do not change tests. Do not delegate or access the network.'
 base['agent']['kvprobe']['steps']=10
 (configroot/'opencode.json').write_text(json.dumps(base,indent=2))
 # Reuse installed provider adapter to avoid another npm install.
 shutil.copytree('/tmp/tensorfold-kv-int4-20261011/opencode-config/opencode/node_modules',configroot/'node_modules',dirs_exist_ok=True)
 env=os.environ.copy(); env.update(XDG_CONFIG_HOME=str(configroot.parent),XDG_CACHE_HOME=str(ROOT/(variant+'-cache')),XDG_DATA_HOME=str(ROOT/(variant+'-data')),OPENCODE_DISABLE_UPDATE_CHECK='true')
 results=[]
 for name,spec in CASES.items():
  fixture=ROOT/'fixtures'/variant/name; fixture.mkdir(parents=True,exist_ok=True)
  (fixture/spec['file']).write_text(spec['initial']); (fixture/'test_public.py').write_text(spec['public'])
  before=hashlib.sha256((fixture/'test_public.py').read_bytes()).hexdigest()
  events=ROOT/'results'/f'opencode-{variant}-{name}.jsonl'; err=events.with_suffix('.stderr.txt')
  t=time.monotonic()
  with events.open('w') as out,err.open('w') as e:
   try: ret=subprocess.run(['/Users/albertpalaciosjimenez/.opencode/bin/opencode','run','--pure','--format','json','--agent','kvprobe','--model','spark/'+model,'--dir',str(fixture),spec['prompt']],env=env,stdout=out,stderr=e,timeout=600).returncode
   except subprocess.TimeoutExpired: ret=124
  elapsed=time.monotonic()-t
  # Held-out tests were inaccessible while the agent ran.
  hidden=ROOT/'heldout'/variant/name; hidden.mkdir(parents=True,exist_ok=True); (hidden/'test_hidden.py').write_text(spec['heldout'])
  checkenv=os.environ.copy(); checkenv['PYTHONPATH']=str(fixture)
  checks={}
  for kind,path in [('public',fixture),('hidden',hidden)]:
   p=subprocess.run(['python3','-m','unittest','discover','-s',str(path),'-v'],env=checkenv,text=True,capture_output=True)
   checks[kind]={'exit_code':p.returncode,'output':p.stdout+p.stderr}
  tools=[]; errors=[]
  for line in events.read_text().splitlines():
   try: event=json.loads(line)
   except: continue
   if event.get('type')=='tool_use': tools.append(event.get('part',{}).get('tool'))
   if event.get('type')=='error': errors.append(event)
  result={'variant':variant,'case':name,'opencode_exit':ret,'wall_s':elapsed,'tools':tools,'errors':errors,'public_tests_unchanged':before==hashlib.sha256((fixture/'test_public.py').read_bytes()).hexdigest(),'checks':checks,'source':(fixture/spec['file']).read_text()}
  results.append(result); print(json.dumps({k:v for k,v in result.items() if k not in ['source','checks']})+f' public={checks["public"]["exit_code"]} hidden={checks["hidden"]["exit_code"]}',flush=True)
  (ROOT/'results'/f'opencode-{variant}-summary.json').write_text(json.dumps(results,indent=2))
 if variant=='exl3':
  image='/tmp/tensorfold-kv-int4-20261011/kv-vision-three-red.png'
  with (ROOT/'results'/'opencode-exl3-vision.jsonl').open('w') as out,(ROOT/'results'/'opencode-exl3-vision.stderr.txt').open('w') as e:
   subprocess.run(['/Users/albertpalaciosjimenez/.opencode/bin/opencode','run','--pure','--format','json','--agent','kvvision','--model','spark/'+model,'--dir',str(ROOT/'fixtures'/variant),'--file',image,'--','How many red rectangles are in this image? Reply with the count and color.'],env=env,stdout=out,stderr=e,timeout=240)
if __name__=='__main__':
 import sys
 run(sys.argv[1],sys.argv[2])
