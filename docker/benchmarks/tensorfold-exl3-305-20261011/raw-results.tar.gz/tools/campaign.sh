#!/bin/bash
set -euo pipefail
variant="$1"
container="$2"
root="$HOME/tensorfold-exl3-305-20261011"
pid=$(docker top "$container" -eo pid,comm | awk '$2=="tensorfold" {print $1}')
for spec in decode:2 decode:3 prefill:1 mixed:1; do
  workload=${spec%:*}
  trial=${spec#*:}
  python3 "$root/tools/bench_long_context.py" --base-url http://127.0.0.1:8000 --n 16 --trial "$trial" --run-tag "$variant-$workload-$trial" --prompt-seed kv-int4-20261011 --variant "$variant" --pair-set exl3-305 --outdir "$root/results" --max-tokens 512 --workload "$workload" --omit-top-k --omit-generation-seed --pid "$pid" --no-gpu-monitor --save-prompts
 done
