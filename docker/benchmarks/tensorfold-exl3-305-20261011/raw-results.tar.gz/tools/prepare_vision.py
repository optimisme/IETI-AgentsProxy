"""Extract only EXL3 visual tensors, then use TensorFold's official CPU converter."""
import hashlib,json,os,sys
from pathlib import Path
import numpy as np
import torch
from safetensors import safe_open
from safetensors.numpy import save_file
from tensorfold.vision.qwen_checkpoint import vision_tensors,vision_key
from tensorfold.vision.exl3_convert import convert
model=Path(sys.argv[1]);root=Path(sys.argv[2]);root.mkdir(parents=True,exist_ok=True)
config=(model/'config.json').read_bytes();conf=root/'config.json'
if conf.exists() and conf.read_bytes()!=config: raise SystemExit('vision artifact config mismatch')
conf.write_bytes(config)
source=root/'vision-exl3-packed.safetensors';out=root/'vision-f16.safetensors'
meta={'source_model':os.environ['MODEL_ID'],'source_revision':os.environ['MODEL_REVISION'],'extractor_version':'1','config_sha256':hashlib.sha256(config).hexdigest()}
if source.exists():
 with safe_open(str(source),framework='np') as f:
  if f.metadata()!=meta: raise SystemExit('vision artifact source mismatch')
else:
 selected=vision_tensors(model);byfile={};tensors={}
 for name,(path,info,begin) in selected.items():byfile.setdefault(path,set()).add(name)
 for path,names in byfile.items():
  with safe_open(str(path),framework='pt',device='cpu') as f:
   for original in f.keys():
    local=vision_key(original)
    if local not in names: continue
    value=f.get_tensor(original)
    # BF16 values are exactly representable in F32; official conversion casts to F16.
    if value.dtype==torch.bfloat16:value=value.float()
    tensors['vision_tower.'+local]=value.numpy()
 if len(tensors)!=len(selected):raise SystemExit('incomplete extracted vision sidecar')
 temp=source.with_name(source.name+f'.tmp-{os.getpid()}')
 save_file(tensors,str(temp),metadata=meta);os.replace(temp,source)
 print(f'[ieti] Extracted {len(tensors)} vision tensors from pinned EXL3 pack',flush=True)
 del tensors
convert(source,out)
os.environ['TENSORFOLD_VISION_WEIGHTS']=str(out)
from tensorfold.vision.qwen_cuda import checkpoint_vision
_,size=checkpoint_vision(model)
print(f'[ieti] Official EXL3 vision converter: validated {out}, tower {size/2**30:.2f} GiB, SHA-256={hashlib.sha256(out.read_bytes()).hexdigest()}',flush=True)
