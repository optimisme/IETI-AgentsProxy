"""Aggregate CSV amounts per account using exact decimal arithmetic."""

import csv
import io
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

_TWO_PLACES = Decimal("0.01")
_ZERO = Decimal("0")


def totals(csv_text):
    """Sum ``account,amount`` rows and return per-account Decimal totals.

    The first non-empty CSV row is treated as the ``account,amount`` header
    and skipped. Account names are trimmed; blank accounts and invalid or
    non-finite Decimal amounts raise ``ValueError``. Per-account sums are
    accumulated exactly and only the final total is rounded to two decimal
    places with ROUND_HALF_UP. The returned dict preserves first-seen
    account order.
    """
    # newline='' on StringIO mirrors the documented csv.reader file-opening
    # mode so CRLF line endings and embedded newlines in quoted fields work.
    rows = list(csv.reader(io.StringIO(csv_text, newline="")))

    # Skip the header row (the first row that actually has content).
    for index, row in enumerate(rows):
        if any(field.strip() for field in row):
            rows = rows[index + 1:]
            break
    else:
        rows = []

    totals_by_account = {}
    for row in rows:
        if not row or all(not field.strip() for field in row):
            continue  # blank filler line
        if len(row) < 2:
            raise ValueError(f"malformed row (missing amount): {row!r}")

        account = row[0].strip()
        if not account:
            raise ValueError(f"blank account: {row!r}")

        raw_amount = row[1].strip()
        try:
            amount = Decimal(raw_amount)
        except InvalidOperation:
            raise ValueError(f"invalid amount: {raw_amount!r}")
        if not amount.is_finite():
            raise ValueError(f"non-finite amount: {raw_amount!r}")

        # Exact accumulation; rounding happens only on the final total.
        totals_by_account[account] = totals_by_account.get(account, _ZERO) + amount

    # dict(...) preserves insertion order (first-seen account order).
    return {
        account: total.quantize(_TWO_PLACES, rounding=ROUND_HALF_UP)
        for account, total in totals_by_account.items()
    }
