import heapq


def order_tasks(deps):
    """Return a topological ordering of tasks given their prerequisites.

    ``deps`` maps each task name to an iterable of prerequisite task names.
    At each step the lexicographically smallest ready task is chosen.
    Duplicate prerequisites are ignored. Raises ValueError if a prerequisite
    is not itself a task (missing prerequisite) or if the graph has a cycle
    (including a self-dependency). The input mapping is never mutated.
    """
    if not deps:
        return []

    # Deduplicate prerequisites and validate that every prerequisite is a task.
    prereqs = {}
    for task, prereq_list in deps.items():
        unique = set(prereq_list)
        for p in unique:
            if p not in deps:
                raise ValueError(f"missing prerequisite {p!r} for task {task!r}")
        prereqs[task] = unique

    # Kahn's algorithm: in-degree = number of unique prerequisites;
    # dependents maps a task to the tasks that require it.
    indegree = {task: len(pres) for task, pres in prereqs.items()}
    dependents = {task: [] for task in deps}
    for task, pres in prereqs.items():
        for p in pres:
            dependents[p].append(task)

    # Min-heap keeps the ready set ordered lexicographically.
    ready = [task for task, deg in indegree.items() if deg == 0]
    heapq.heapify(ready)

    order = []
    while ready:
        task = heapq.heappop(ready)
        order.append(task)
        for nxt in dependents[task]:
            indegree[nxt] -= 1
            if indegree[nxt] == 0:
                heapq.heappush(ready, nxt)

    if len(order) != len(deps):
        raise ValueError("dependency cycle detected")

    return order
