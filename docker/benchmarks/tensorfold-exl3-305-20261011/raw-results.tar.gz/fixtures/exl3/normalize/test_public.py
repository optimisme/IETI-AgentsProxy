import unittest
from normalize import normalize_names
class Tests(unittest.TestCase):
 def test_basic(self): self.assertEqual(normalize_names([' Bob ', 'ALICE', 'bob', '', '  ']), ['bob', 'alice'])
 def test_no_mutation(self):
  values=[' Bob ','Bob']; before=values.copy(); normalize_names(values); self.assertEqual(values,before)
