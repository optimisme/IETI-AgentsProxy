def normalize_names(values):
    seen = set()
    result = []
    for value in values:
        name = value.strip().casefold()
        if not name or name in seen:
            continue
        seen.add(name)
        result.append(name)
    return result
