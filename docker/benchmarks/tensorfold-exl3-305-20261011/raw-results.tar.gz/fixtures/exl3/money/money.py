import csv
import io
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


def totals(csv_text):
    """Aggregate exact Decimal amounts per account from CSV text.

    The input must have headers ``account,amount``. Account names are
    trimmed; blank accounts and invalid/non-finite amounts raise ValueError.
    Amounts are summed exactly per account and only the final per-account
    total is rounded to two decimal places with ROUND_HALF_UP. Insertion
    order of accounts is preserved. Quoted accounts containing commas,
    CRLF line endings and header-only (empty) input are supported.
    """
    # newline='' lets the csv module handle CRLF and embedded newlines
    # inside quoted fields correctly.
    reader = csv.reader(io.StringIO(csv_text, newline=''))

    # Consume the header row (account,amount). Header-only input yields
    # no data rows and therefore an empty result.
    next(reader, None)

    # Plain dict preserves insertion order (Python 3.7+).
    sums = {}
    for row in reader:
        if len(row) < 2:
            raise ValueError("row must contain account and amount fields")

        account = row[0].strip()
        if not account:
            raise ValueError("account must not be blank")

        raw_amount = row[1].strip()
        try:
            amount = Decimal(raw_amount)
        except InvalidOperation:
            raise ValueError("invalid amount: {!r}".format(raw_amount))

        if not amount.is_finite():
            raise ValueError("amount must be finite: {!r}".format(raw_amount))

        # Sum exact amounts; rounding happens only on the final total.
        if account in sums:
            sums[account] += amount
        else:
            sums[account] = amount

    return {
        account: total.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        for account, total in sums.items()
    }
