import unittest
from decimal import Decimal
from money import totals
class Tests(unittest.TestCase):
 def test_basic(self): self.assertEqual(totals('account,amount\na,0.1\na,0.2\nb,2.345\n'),{'a':Decimal('0.30'),'b':Decimal('2.35')})
 def test_empty(self): self.assertEqual(totals('account,amount\n'),{})
