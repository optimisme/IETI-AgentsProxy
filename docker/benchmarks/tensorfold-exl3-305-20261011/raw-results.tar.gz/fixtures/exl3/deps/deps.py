import heapq


def order_tasks(deps):
    """Return a topological ordering of tasks.

    ``deps`` maps each task name to an iterable of prerequisite task names.
    At each step the lexicographically smallest currently-ready task is chosen.
    Duplicate prerequisites count once. Raises ``ValueError`` on a missing
    prerequisite or any cycle (including a self dependency). Empty input
    returns ``[]``. The input mapping and its iterables are not mutated.
    """
    # Snapshot the task names without mutating the input.
    tasks = list(deps.keys())

    # Deduplicate prerequisites per task and validate they all exist.
    prereqs = {}
    for task in tasks:
        seen = set()
        for p in deps[task]:
            if p not in deps:
                raise ValueError(
                    "missing prerequisite {!r} for task {!r}".format(p, task)
                )
            seen.add(p)
        prereqs[task] = seen

    # Build reverse edges (successors) and in-degrees from deduped prereqs.
    successors = {task: [] for task in tasks}
    indeg = {}
    for task in tasks:
        indeg[task] = len(prereqs[task])
        for p in prereqs[task]:
            successors[p].append(task)

    # Kahn's algorithm, always popping the lexicographically smallest ready task.
    heap = [task for task in tasks if indeg[task] == 0]
    heapq.heapify(heap)

    result = []
    while heap:
        task = heapq.heappop(heap)
        result.append(task)
        for nxt in successors[task]:
            indeg[nxt] -= 1
            if indeg[nxt] == 0:
                heapq.heappush(heap, nxt)

    if len(result) != len(tasks):
        raise ValueError("cycle detected among tasks")

    return result
