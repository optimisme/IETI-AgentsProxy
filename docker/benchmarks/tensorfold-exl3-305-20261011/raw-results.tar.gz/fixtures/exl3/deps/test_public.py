import unittest
from deps import order_tasks
class Tests(unittest.TestCase):
 def test_chain(self): self.assertEqual(order_tasks({'a':['z'],'z':[]}),['z','a'])
 def test_tie(self): self.assertEqual(order_tasks({'c':['a'],'b':[],'a':[]}),['a','b','c'])
 def test_cycle(self):
  with self.assertRaises(ValueError): order_tasks({'a':['b'],'b':['a']})
