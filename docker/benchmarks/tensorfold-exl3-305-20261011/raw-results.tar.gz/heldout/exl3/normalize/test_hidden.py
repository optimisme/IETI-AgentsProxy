import unittest
from normalize import normalize_names
class Hidden(unittest.TestCase):
 def test_unicode(self): self.assertEqual(normalize_names(['Straße','STRASSE',' École ','ÉCOLE']),['strasse','école'])
 def test_generator(self): self.assertEqual(normalize_names(x for x in [' B ','a','b',' c ']),['b','a','c'])
 def test_empty(self): self.assertEqual(normalize_names(iter([])),[])
 def test_order(self): self.assertEqual(normalize_names(['Z','A','z','C','a']),['z','a','c'])
