import unittest
from deps import order_tasks
class Hidden(unittest.TestCase):
 def test_new_ready_precedes(self): self.assertEqual(order_tasks({'z':[],'b':['a'],'a':[]}),['a','b','z'])
 def test_dupes(self): self.assertEqual(order_tasks({'b':['a','a'],'a':[]}),['a','b'])
 def test_missing(self):
  with self.assertRaises(ValueError): order_tasks({'a':['absent']})
 def test_self_cycle(self):
  with self.assertRaises(ValueError): order_tasks({'a':['a']})
 def test_empty(self): self.assertEqual(order_tasks({}),[])
 def test_mutation(self):
  d={'b':['a'],'a':[]}; order_tasks(d); self.assertEqual(d,{'b':['a'],'a':[]})
