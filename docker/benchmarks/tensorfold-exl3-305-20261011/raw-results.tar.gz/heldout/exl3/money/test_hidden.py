import unittest
from decimal import Decimal
from money import totals
class Hidden(unittest.TestCase):
 def test_sum_before_round(self): self.assertEqual(totals('account,amount\nx,0.004\nx,0.004\n'),{'x':Decimal('0.01')})
 def test_negative_half(self): self.assertEqual(totals('account,amount\nx,-1.005\n'),{'x':Decimal('-1.01')})
 def test_quoted(self): self.assertEqual(totals('account,amount\r\n" Team, A ",1.20\r\n'),{'Team, A':Decimal('1.20')})
 def test_nonfinite(self):
  for amount in ['NaN','Infinity','-Infinity','nope']:
   with self.subTest(amount=amount),self.assertRaises(ValueError): totals('account,amount\nx,'+amount+'\n')
 def test_blank(self):
  with self.assertRaises(ValueError): totals('account,amount\n ,2\n')
 def test_type_order(self):
  r=totals('account,amount\nz,1\na,2\n'); self.assertEqual(list(r),['z','a']); self.assertTrue(all(isinstance(x,Decimal) for x in r.values()))
